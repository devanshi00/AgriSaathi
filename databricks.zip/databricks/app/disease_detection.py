"""
Plant Disease Detection Module
AI-powered crop disease diagnosis using computer vision with RAG-enhanced recommendations
"""
import streamlit as st
import pandas as pd
import random
from huggingface_hub import InferenceClient
from PIL import Image
import io
import pickle
import os
import numpy as np
import requests

# RAG Pipeline imports
try:
    import faiss
    from sentence_transformers import SentenceTransformer
    RAG_AVAILABLE = True
except ImportError:
    RAG_AVAILABLE = False
    st.warning("⚠️ RAG features unavailable: faiss-cpu and sentence-transformers not installed")
HF_API_KEY = "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"
HF_MODEL   = "linkanjarad/mobilenet_v2_1.0_224-plant-disease-identification"
# ✅ Correct
HF_API_URL = f"https://router.huggingface.co/hf-inference/models/{HF_MODEL}"
# Disease database for different crops
CROP_DISEASES = {
    "Wheat": [
        {"name": "Leaf Rust", "severity": "High", "symptoms": "Orange-brown pustules on leaves", "prevention": "Use resistant varieties, fungicide spray"},
        {"name": "Stem Rust", "severity": "High", "symptoms": "Reddish-brown pustules on stems", "prevention": "Early sowing, resistant varieties"},
        {"name": "Powdery Mildew", "severity": "Medium", "symptoms": "White powdery growth on leaves", "prevention": "Proper spacing, avoid excess nitrogen"},
        {"name": "Fusarium Head Blight", "severity": "High", "symptoms": "Premature bleaching of heads", "prevention": "Crop rotation, fungicide at flowering"}
    ],
    "Rice": [
        {"name": "Blast Disease", "severity": "High", "symptoms": "Diamond-shaped lesions on leaves", "prevention": "Use resistant varieties, balanced fertilization"},
        {"name": "Bacterial Leaf Blight", "severity": "High", "symptoms": "Water-soaked lesions turning yellow", "prevention": "Use certified seeds, avoid excess nitrogen"},
        {"name": "Sheath Blight", "severity": "Medium", "symptoms": "Oval spots on leaf sheath", "prevention": "Proper water management, fungicide"},
        {"name": "Brown Spot", "severity": "Medium", "symptoms": "Circular brown spots on leaves", "prevention": "Balanced nutrients, seed treatment"}
    ],
    "Cotton": [
        {"name": "Bacterial Blight", "severity": "High", "symptoms": "Water-soaked angular spots", "prevention": "Resistant varieties, seed treatment"},
        {"name": "Fusarium Wilt", "severity": "High", "symptoms": "Wilting and yellowing of leaves", "prevention": "Crop rotation, resistant varieties"},
        {"name": "Alternaria Leaf Spot", "severity": "Medium", "symptoms": "Circular brown spots with concentric rings", "prevention": "Fungicide spray, proper spacing"},
        {"name": "Grey Mildew", "severity": "Medium", "symptoms": "White powdery growth on lower leaf surface", "prevention": "Avoid overhead irrigation, fungicide"}
    ],
    "Tomato": [
        {"name": "Late Blight", "severity": "High", "symptoms": "Water-soaked lesions, white mold", "prevention": "Copper-based fungicide, remove infected parts"},
        {"name": "Early Blight", "severity": "Medium", "symptoms": "Dark brown spots with concentric rings", "prevention": "Crop rotation, mulching"},
        {"name": "Bacterial Wilt", "severity": "High", "symptoms": "Sudden wilting without yellowing", "prevention": "Resistant varieties, soil solarization"},
        {"name": "Septoria Leaf Spot", "severity": "Medium", "symptoms": "Small circular spots with gray centers", "prevention": "Remove lower leaves, fungicide spray"}
    ],
    "Potato": [
        {"name": "Late Blight", "severity": "High", "symptoms": "Dark water-soaked lesions on leaves", "prevention": "Fungicide spray, destroy infected plants"},
        {"name": "Early Blight", "severity": "Medium", "symptoms": "Brown spots with concentric rings", "prevention": "Crop rotation, avoid overhead watering"},
        {"name": "Black Scurf", "severity": "Medium", "symptoms": "Black sclerotia on tubers", "prevention": "Seed treatment, proper storage"},
        {"name": "Common Scab", "severity": "Low", "symptoms": "Rough corky lesions on tubers", "prevention": "Maintain soil pH 5.2-5.5, irrigation"}
    ],
    "Soybean": [
        {"name": "Rust", "severity": "High", "symptoms": "Reddish-brown pustules on leaves", "prevention": "Resistant varieties, fungicide"},
        {"name": "Bacterial Blight", "severity": "Medium", "symptoms": "Small water-soaked spots on leaves", "prevention": "Use certified seeds, crop rotation"},
        {"name": "Frogeye Leaf Spot", "severity": "Medium", "symptoms": "Circular spots with gray centers", "prevention": "Resistant varieties, fungicide"},
        {"name": "Stem Canker", "severity": "High", "symptoms": "Reddish-brown cankers on stems", "prevention": "Resistant varieties, crop rotation"}
    ],
    "Maize": [
        {"name": "Turcicum Leaf Blight", "severity": "High", "symptoms": "Long elliptical gray-green lesions", "prevention": "Resistant hybrids, crop rotation"},
        {"name": "Maydis Leaf Blight", "severity": "High", "symptoms": "Rectangular lesions parallel to veins", "prevention": "Resistant varieties, balanced fertilization"},
        {"name": "Common Rust", "severity": "Medium", "symptoms": "Reddish-brown pustules on leaves", "prevention": "Resistant hybrids, early sowing"},
        {"name": "Stalk Rot", "severity": "High", "symptoms": "Rotting of lower internodes", "prevention": "Avoid water stress, proper plant density"}
    ],
    "Onion": [
        {"name": "Purple Blotch", "severity": "High", "symptoms": "Sunken lesions with purple margins", "prevention": "Crop rotation, fungicide spray"},
        {"name": "Stemphylium Blight", "severity": "Medium", "symptoms": "Small brown spots on leaves", "prevention": "Avoid overhead irrigation, fungicide"},
        {"name": "Downy Mildew", "severity": "High", "symptoms": "Pale yellow spots, gray mold", "prevention": "Proper spacing, resistant varieties"},
        {"name": "Basal Rot", "severity": "Medium", "symptoms": "Rotting of bulb base", "prevention": "Well-drained soil, proper curing"}
    ]
}

# ═══════════════════════════════════════════════════════════════════════
# RAG PIPELINE FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════

@st.cache_resource
def load_rag_pipeline():
    """Load FAISS index and chunks from croppulse_vol"""
    if not RAG_AVAILABLE:
        return None, None, None
    
    try:
        # Paths to FAISS index and chunks
        vol_path = "/Volumes/main/default/croppulse_vol"
        index_path = os.path.join(vol_path, "index.faiss")
        chunks_path = os.path.join(vol_path, "chunks.pkl")
        
        # Check if files exist
        if not os.path.exists(index_path) or not os.path.exists(chunks_path):
            st.warning(f"⚠️ RAG files not found in {vol_path}")
            return None, None, None
        
        # Load FAISS index
        index = faiss.read_index(index_path)
        
        # Load chunks
        with open(chunks_path, "rb") as f:
            chunks_data = pickle.load(f)
        
        # Load sentence transformer model
        model = SentenceTransformer("all-MiniLM-L6-v2")
        
        st.success(f"✅ RAG Pipeline loaded: {len(chunks_data)} chunks indexed")
        return index, chunks_data, model
    
    except Exception as e:
        st.error(f"❌ Error loading RAG pipeline: {str(e)}")
        return None, None, None

def query_rag_pipeline(query, index, chunks_data, model, top_k=3):
    """
    Query the RAG pipeline for relevant agricultural knowledge
    
    Args:
        query: Search query string
        index: FAISS index
        chunks_data: List of text chunks with metadata
        model: Sentence transformer model
        top_k: Number of results to return
        
    Returns:
        List of relevant chunks with scores
    """
    if not RAG_AVAILABLE or index is None or chunks_data is None or model is None:
        return []
    
    try:
        # Encode query
        q_embed = model.encode([query], normalize_embeddings=True).astype("float32")
        
        # Search FAISS index
        scores, indices = index.search(q_embed, top_k)
        
        # Retrieve chunks
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < len(chunks_data):
                chunk = chunks_data[idx]
                results.append({
                    "text": chunk.get("text", ""),
                    "source": chunk.get("source_doc", "Unknown"),
                    "page": chunk.get("page", "N/A"),
                    "score": float(score)
                })
        
        return results
    
    except Exception as e:
        st.error(f"RAG query error: {str(e)}")
        return []

def get_rag_enhanced_recommendations(disease_name, crop_type=""):
    """
    Get treatment recommendations enhanced with RAG-retrieved knowledge
    
    Args:
        disease_name: Name of the detected disease
        crop_type: Type of crop (optional)
        
    Returns:
        str: Enhanced recommendations with RAG context
    """
    # Load RAG pipeline
    index, chunks_data, model = load_rag_pipeline()
    
    # Base query for RAG
    query = f"{crop_type} {disease_name} treatment prevention storage".strip()
    
    # Get RAG results
    rag_results = query_rag_pipeline(query, index, chunks_data, model, top_k=2)
    
    # Build enhanced recommendations
    recommendations = f"### 💊 Treatment Recommendations for {disease_name}\n\n"
    
    # Add RAG-enhanced context if available
    if rag_results:
        recommendations += "#### 📚 Expert Knowledge from Agricultural Documents:\n\n"
        for i, result in enumerate(rag_results, 1):
            recommendations += f"**Source {i}:** {result['source']} (Page {result['page']}, Relevance: {result['score']:.2f})\n\n"
            recommendations += f"> {result['text'][:300]}...\n\n"
        recommendations += "---\n\n"
    
    # Add standard treatment advice
    disease_lower = disease_name.lower()
    
    if 'blight' in disease_lower:
        recommendations += """**Immediate Actions:**
- Apply copper-based fungicide immediately
- Remove and destroy all infected plant parts
- Improve air circulation between plants
- Avoid overhead watering
- Apply fungicide every 7-10 days until symptoms reduce

**Long-term Prevention:**
- Use resistant varieties in next planting
- Practice crop rotation (3-4 year cycle)
- Maintain proper plant spacing
- Monitor weather conditions (high humidity increases risk)"""
    
    elif 'rust' in disease_lower:
        recommendations += """**Immediate Actions:**
- Apply systemic fungicide (e.g., Mancozeb, Propiconazole)
- Remove severely infected leaves
- Ensure proper plant spacing for air circulation
- Avoid high nitrogen fertilization
- Repeat fungicide application every 10-14 days

**Long-term Prevention:**
- Plant resistant varieties
- Avoid planting in shaded, humid areas
- Apply sulfur dust as preventive measure
- Monitor regularly during humid weather"""
    
    elif 'wilt' in disease_lower or 'bacterial' in disease_lower:
        recommendations += """**Immediate Actions:**
- Remove and burn infected plants immediately
- Do not compost infected material
- Disinfect tools with 10% bleach solution
- Improve soil drainage
- Avoid working in wet conditions

**Long-term Prevention:**
- Practice 3-4 year crop rotation (avoid same family)
- Use disease-free seeds/transplants
- Soil solarization in summer months
- Use resistant varieties
- Improve field drainage systems"""
    
    elif 'healthy' in disease_lower:
        recommendations += """**Preventive Maintenance:**
✅ Your plants are healthy! Continue current practices:

- Regular monitoring for early disease detection
- Maintain good field hygiene
- Ensure balanced fertilization (avoid excess nitrogen)
- Proper irrigation management (avoid overwatering)
- Scout fields weekly for pest/disease symptoms
- Maintain crop rotation schedules
- Use certified disease-free seeds"""
    
    else:
        recommendations += """**General Disease Management:**

**Immediate Actions:**
- Apply broad-spectrum fungicide or bactericide
- Improve plant spacing and air circulation
- Remove infected plant parts promptly
- Monitor plants daily for symptom progression
- Adjust irrigation to avoid leaf wetness

**Long-term Prevention:**
- Use certified disease-free planting material
- Practice crop rotation (minimum 2-3 years)
- Maintain plant health through balanced nutrition
- Use resistant varieties when available
- Consult local agricultural extension officer"""
    
    return recommendations


# def predict_disease_with_ml(image_file):
#     """
#     Use Hugging Face ML model to predict plant disease from image
    
#     Args:
#         image_file: Uploaded file object from Streamlit
        
#     Returns:
#         dict: Prediction result with disease name and confidence
#     """
#     try:
#         client = InferenceClient(
#             provider="hf-inference",
#             api_key="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"
#         )

#         # Read uploaded file
#         image_bytes = image_file.getvalue()
#         image = Image.open(io.BytesIO(image_bytes)).convert("RGB")

#         # Save as PNG into a file-like buffer
#         img_buffer = io.BytesIO()
#         image.save(img_buffer, format="PNG")
#         img_buffer.seek(0)

#         # Pass raw bytes instead of the BytesIO object
#         output = client.image_classification(
#             image=img_buffer.getvalue(),
#             model="linkanjarad/mobilenet_v2_1.0_224-plant-disease-identification"
#         )

#         if output and len(output) > 0:
#             top_prediction = max(output, key=lambda x: x.score)
#             return {
#                 "success": True,
#                 "disease": top_prediction.label,
#                 "confidence": round(top_prediction.score * 100, 2),
#                 "all_predictions": [
#                     {
#                         "disease": pred.label,
#                         "confidence": round(pred.score * 100, 2)
#                     }
#                     for pred in sorted(output, key=lambda x: x.score, reverse=True)[:3]
#                 ]
#             }
#         else:
#             return {"success": False, "error": "No predictions returned"}

#     except Exception as e:
#         return {"success": False, "error": str(e)}


def _prepare_image_bytes(image_file) -> bytes:
    """
    Read the Streamlit UploadedFile, resize to 224×224 (what the model
    was trained on), convert to RGB, and return raw PNG bytes.
    """
    raw = image_file.getvalue()
    image = Image.open(io.BytesIO(raw)).convert("RGB")
    image = image.resize((224, 224), Image.LANCZOS)
 
    buf = io.BytesIO()
    image.save(buf, format="PNG")
    return buf.getvalue()
 
 
def predict_disease_with_ml(image_file):
    """
    Use Hugging Face Inference API to predict plant disease from an image.
 
    Args:
        image_file: Uploaded file object from Streamlit
                    (must support .getvalue())
 
    Returns:
        dict: {
            "success": bool,
            "disease": str,          # top label
            "confidence": float,     # top score as percentage
            "all_predictions": [     # top-3 sorted by confidence
                {"disease": str, "confidence": float}, ...
            ]
        }
        or on failure:
        dict: {"success": False, "error": str}
    """
    try:
        # ── 1. Prepare image ────────────────────────────────────────────
        img_bytes = _prepare_image_bytes(image_file)
 
        # ── 2. Call the Inference API via requests (most stable method) ─
        headers = {
            "Authorization": f"Bearer {HF_API_KEY}",
            "Content-Type": "image/png",
        }
 
        response = requests.post(
            HF_API_URL,
            headers=headers,
            data=img_bytes,
            timeout=60,          # model may need to load cold-start
        )
 
        # ── 3. Handle HTTP-level errors ─────────────────────────────────
        if response.status_code == 503:
            # Model is loading — surface a clear message to the user
            detail = response.json().get("estimated_time", "unknown")
            return {
                "success": False,
                "error": (
                    f"Model is loading on Hugging Face servers "
                    f"(estimated wait: {detail}s). Please try again in a moment."
                ),
            }
 
        if response.status_code != 200:
            return {
                "success": False,
                "error": f"API error {response.status_code}: {response.text}",
            }
 
        # ── 4. Parse predictions ─────────────────────────────────────────
        output = response.json()   # list of {"label": str, "score": float}
 
        if not isinstance(output, list) or len(output) == 0:
            return {"success": False, "error": "No predictions returned from model."}
 
        sorted_preds = sorted(output, key=lambda x: x["score"], reverse=True)
        top = sorted_preds[0]
 
        return {
            "success": True,
            "disease": top["label"],
            "confidence": round(top["score"] * 100, 2),
            "all_predictions": [
                {
                    "disease": pred["label"],
                    "confidence": round(pred["score"] * 100, 2),
                }
                for pred in sorted_preds[:3]
            ],
        }
 
    except requests.exceptions.Timeout:
        return {
            "success": False,
            "error": "Request timed out. The model may be loading — please try again.",
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def map_ml_prediction_to_severity(disease_name):
    """
    Map ML model disease prediction to severity level
    
    Args:
        disease_name: Disease name from ML model
        
    Returns:
        str: Severity level (High, Medium, Low)
    """
    disease_lower = disease_name.lower()
    
    # High severity keywords
    if any(word in disease_lower for word in ['blight', 'rust', 'wilt', 'rot', 'canker', 'bacterial']):
        return "High"
    
    # Medium severity keywords
    elif any(word in disease_lower for word in ['spot', 'mildew', 'scab', 'leaf']):
        return "Medium"
    
    # Low severity or healthy
    elif any(word in disease_lower for word in ['healthy', 'minor', 'scurf']):
        return "Low"
    
    # Default to medium
    else:
        return "Medium"


def show_disease_detection():
    """Display plant disease detection interface with crop selection"""
    
    # Apply dark theme CSS
    st.markdown("""
    <style>
    /* Dark Theme Variables */
    :root {
        --bg-primary: #1a1d29;
        --bg-secondary: #252936;
        --bg-tertiary: #2d3142;
        --accent-blue: #3b82f6;
        --accent-green: #10b981;
        --accent-red: #ef4444;
        --accent-orange: #f59e0b;
        --text-primary: #e2e8f0;
        --text-secondary: #94a3b8;
        --border-color: #3f4556;
    }
    
    /* Dark header styling */
    .dark-header {
        background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
        color: #f1f5f9;
        padding: 24px;
        border-radius: 16px;
        margin-bottom: 24px;
        border: 1px solid #475569;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
    }
    
    .dark-header h3 {
        margin: 0 0 8px 0;
        color: #f1f5f9;
        font-size: 28px;
        font-weight: 700;
    }
    
    .dark-header p {
        margin: 0;
        color: #cbd5e1;
        font-size: 15px;
    }
    
    /* Dark card styling for disease info */
    .disease-card-dark {
        background: linear-gradient(135deg, #1e293b 0%, #252936 100%);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 16px;
        border: 1px solid var(--border-color);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
        transition: all 0.3s ease;
    }
    
    .disease-card-dark:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.5);
        border-color: var(--accent-blue);
    }
    
    .disease-card-dark h4 {
        color: #f1f5f9;
        font-size: 18px;
        font-weight: 700;
        margin: 0 0 12px 0;
    }
    
    .disease-card-dark p {
        color: #94a3b8;
        font-size: 14px;
        margin: 8px 0;
        line-height: 1.6;
    }
    
    .disease-card-dark strong {
        color: #cbd5e1;
    }
    
    /* Severity badges with dark theme */
    .severity-badge {
        display: inline-block;
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .severity-high {
        background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);
        color: white;
        box-shadow: 0 2px 8px rgba(239, 68, 68, 0.4);
    }
    
    .severity-medium {
        background: linear-gradient(135deg, #d97706 0%, #f59e0b 100%);
        color: white;
        box-shadow: 0 2px 8px rgba(245, 158, 11, 0.4);
    }
    
    .severity-low {
        background: linear-gradient(135deg, #059669 0%, #10b981 100%);
        color: white;
        box-shadow: 0 2px 8px rgba(16, 185, 129, 0.4);
    }
    
    /* Alert boxes with dark theme */
    .disease-alert-dark {
        background: linear-gradient(135deg, #1e1b1b 0%, #2d1f1f 100%);
        border-left: 4px solid #ef4444;
        padding: 20px;
        border-radius: 12px;
        margin: 16px 0;
        color: #fecaca;
        box-shadow: 0 4px 12px rgba(239, 68, 68, 0.2);
    }
    
    .disease-warning-dark {
        background: linear-gradient(135deg, #1e1e1b 0%, #2d2a1f 100%);
        border-left: 4px solid #f59e0b;
        padding: 20px;
        border-radius: 12px;
        margin: 16px 0;
        color: #fde68a;
        box-shadow: 0 4px 12px rgba(245, 158, 11, 0.2);
    }
    
    .disease-safe-dark {
        background: linear-gradient(135deg, #1b1e1e 0%, #1f2d27 100%);
        border-left: 4px solid #10b981;
        padding: 20px;
        border-radius: 12px;
        margin: 16px 0;
        color: #a7f3d0;
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.2);
    }
    
    .disease-alert-dark h4,
    .disease-warning-dark h4,
    .disease-safe-dark h4 {
        margin: 0 0 8px 0;
        font-size: 18px;
    }
    
    .disease-alert-dark p,
    .disease-warning-dark p,
    .disease-safe-dark p {
        margin: 4px 0;
        font-size: 14px;
    }
    
    /* Section divider */
    .section-divider {
        height: 1px;
        background: linear-gradient(90deg, transparent, #475569, transparent);
        margin: 32px 0;
    }
    
    /* Chat message styling */
    .chat-message {
        padding: 15px;
        border-radius: 10px;
        margin: 10px 0;
        border-left: 4px solid;
    }
    
    .chat-user {
        background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%);
        border-left-color: #3b82f6;
        color: #e0e7ff;
    }
    
    .chat-assistant {
        background: linear-gradient(135deg, #1e2530 0%, #2d3748 100%);
        border-left-color: #10b981;
        color: #e2e8f0;
    }
    
    .chat-source {
        background: #1a1d29;
        padding: 10px;
        border-radius: 8px;
        margin: 8px 0;
        border-left: 3px solid #f59e0b;
        font-size: 13px;
        color: #cbd5e1;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Header
    st.markdown("""
    <div class="dark-header">
        <h3>🌿 AI-Powered Plant Disease Detection</h3>
        <p>Upload crop images for ML diagnosis enhanced with agricultural knowledge retrieval</p>
    </div>
    """, unsafe_allow_html=True)
    
    # # ══════════════════════════════════════════════════════════════════════
    # # SECTION 1: CROP SELECTION
    # # ══════════════════════════════════════════════════════════════════════
    # col1, col2, col3 = st.columns(3)
    
    # with col1:
    #     crop_type = st.selectbox("🌱 Select Crop", 
    #         ["Wheat", "Rice", "Cotton", "Tomato", "Potato", "Soybean", "Maize", "Onion"],
    #         help="Choose the crop you want to analyze")
    
    # with col2:
    #     region = st.selectbox("🗺️ Region", 
    #         ["North India", "South India", "East India", "West India", "Central India"],
    #         help="Select your farming region")
    
    # with col3:
    #     season = st.selectbox("📅 Season", 
    #         ["Kharif (Monsoon)", "Rabi (Winter)", "Zaid (Summer)"],
    #         help="Current growing season")
    
    # st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
    
    # # ══════════════════════════════════════════════════════════════════════
    # # SECTION 2: POSSIBLE DISEASES FOR SELECTED CROP
    # # ══════════════════════════════════════════════════════════════════════
    # st.markdown(f"### ⚠️ Common Diseases for {crop_type}")
    # st.caption(f"Based on your crop selection, here are the diseases to watch out for in {region} during {season}")
    # st.markdown("")
    
    # diseases = CROP_DISEASES.get(crop_type, [])
    
    # # Display diseases in dark-themed cards
    # for disease in diseases:
    #     severity_class = f"severity-{disease['severity'].lower()}"
        
    #     st.markdown(f"""
    #     <div class="disease-card-dark">
    #         <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 12px;">
    #             <h4>🦠 {disease['name']}</h4>
    #             <span class="severity-badge {severity_class}">{disease['severity']} Risk</span>
    #         </div>
    #         <p><strong>Symptoms:</strong> {disease['symptoms']}</p>
    #         <p><strong>Prevention:</strong> {disease['prevention']}</p>
    #     </div>
    #     """, unsafe_allow_html=True)
    
    # st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
    
    # ══════════════════════════════════════════════════════════════════════
    # SECTION 3: AI IMAGE ANALYSIS WITH ML MODEL + RAG
    # ══════════════════════════════════════════════════════════════════════
    st.markdown("### 📸 AI-Powered Image Analysis with Knowledge Retrieval")
    st.caption("Upload an image for MobileNet ML detection + RAG-enhanced recommendations from agricultural documents")
    st.markdown("")
    
    uploaded_file = st.file_uploader(
        "Choose an image of your crop (leaves, stems, or fruits)",
        type=['jpg', 'jpeg', 'png'],
        help="Supported formats: JPG, JPEG, PNG"
    )
    
    if uploaded_file is not None:
        col1, col2 = st.columns([1, 1])
        
        with col1:
           st.image(uploaded_file, caption="Uploaded Image", use_column_width=True)
        
        with col2:
            if st.button("🔍 Analyze for Diseases", type="primary"):
                with st.spinner("🤖 Analyzing image with MobileNet ML model..."):
                    
                    # Call the ML model for prediction
                    prediction = predict_disease_with_ml(uploaded_file)
                    
                    if prediction["success"]:
                        disease_name = prediction["disease"]
                        confidence = prediction["confidence"]
                        severity = map_ml_prediction_to_severity(disease_name)
                        
                        # Display result based on disease detection
                        if "healthy" in disease_name.lower():
                            st.markdown(f"""
                                <div class="disease-safe-dark">
                                    <h4 style="color: #10b981;">✅ Healthy Plant Detected</h4>
                                    <p style="margin: 8px 0 0 0;"><strong>Detected:</strong> {disease_name}</p>
                                    <p style="margin: 4px 0 0 0;"><strong>Confidence:</strong> {confidence}%</p>
                                    <p style="margin: 8px 0 0 0;">No disease symptoms found. Continue regular monitoring.</p>
                                </div>
                            """, unsafe_allow_html=True)
                        elif severity == "High":
                            st.markdown(f"""
                                <div class="disease-alert-dark">
                                    <h4 style="color: #ef4444;">🚨 {disease_name} Detected</h4>
                                    <p style="margin: 8px 0 0 0;"><strong>Confidence:</strong> {confidence}% | <strong>Severity:</strong> HIGH</p>
                                    <p style="margin: 8px 0 0 0;">Immediate action required!</p>
                                </div>
                            """, unsafe_allow_html=True)
                        else:
                            st.markdown(f"""
                                <div class="disease-warning-dark">
                                    <h4 style="color: #f59e0b;">⚠️ {disease_name} Detected</h4>
                                    <p style="margin: 8px 0 0 0;"><strong>Confidence:</strong> {confidence}% | <strong>Severity:</strong> {severity.upper()}</p>
                                    <p style="margin: 8px 0 0 0;">Monitor closely and take preventive action.</p>
                                </div>
                            """, unsafe_allow_html=True)
                        
                        # Show only top prediction
                        st.markdown("#### 🔬 Detected Disease")
                        top_pred = prediction["all_predictions"][0]
                        st.write(f"**{top_pred['disease']}** - {top_pred['confidence']}% confidence")
                        
                        st.markdown("---")
                        
                        # RAG-Enhanced Treatment Recommendations
                        with st.spinner("📚 Retrieving expert knowledge from agricultural documents..."):
                            recommendations = get_rag_enhanced_recommendations(disease_name, crop_type)
                            st.markdown(recommendations)
                        
                        st.markdown("---")
                        st.info("""
                        **💡 Recommendations Enhanced By:**
                        * MobileNet ML Disease Detection Model
                        * FAISS Vector Search on Agricultural Documents
                        * Sentence Transformer Semantic Matching
                        * Expert agricultural knowledge base
                        
                        **Expert Consultation:** Contact nearest Krishi Vigyan Kendra (KVK) or agricultural extension officer for field-specific guidance.
                        """)
                    else:
                        st.error(f"❌ **Error in ML Model Prediction:** {prediction['error']}")
                        st.info("Please try uploading a clearer image or contact support if the issue persists.")
    else:
        st.info("👆 Upload an image to get AI-powered disease detection with RAG-enhanced recommendations")
        st.caption("💡 **Tip:** For best results, upload clear images of affected plant parts (leaves, stems, fruits) in good lighting")
    
    st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
    