import streamlit as st
import json
import os

def check_credentials(username, password):
    """
    Credential validation with support for JSON file.
    In production, replace with secure authentication.
    """
    users_file = "users.json"
    
    # Try to load from JSON file first
    if os.path.exists(users_file):
        with open(users_file, 'r') as f:
            users = json.load(f)
        if username in users:
            return users[username]["password"] == password
    
    # Fallback to demo credentials
    valid_users = {
        "admin": "admin123",
        "farmer": "farmer123",
        "demo": "demo123"
    }
    return valid_users.get(username) == password

def show_login_page():
    """Display an appealing green-themed login page"""
    
    # Custom CSS for green dark theme styling
    st.markdown("""
        <style>
        /* Main background gradient */
        .main {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%);
            min-height: 100vh;
        }
        
        /* Animated background particles */
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
        }
        
        /* Login container */
        .login-container {
            background: rgba(31, 41, 55, 0.8);
            backdrop-filter: blur(10px);
            padding: 50px 40px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5), 0 0 40px rgba(34, 197, 94, 0.1);
            max-width: 450px;
            margin: 80px auto;
            border: 1px solid rgba(34, 197, 94, 0.2);
            animation: fadeIn 0.6s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Title styling */
        .login-title {
            color: #22C55E;
            text-align: center;
            font-size: 42px;
            font-weight: 800;
            margin-bottom: 8px;
            text-shadow: 0 0 20px rgba(34, 197, 94, 0.3);
            letter-spacing: -1px;
        }
        
        .login-subtitle {
            color: #9CA3AF;
            text-align: center;
            font-size: 16px;
            margin-bottom: 40px;
            font-weight: 400;
        }
        
        /* Logo container with glow effect */
        .logo-container {
            text-align: center;
            font-size: 70px;
            margin-bottom: 25px;
            animation: float 3s ease-in-out infinite;
            filter: drop-shadow(0 0 20px rgba(34, 197, 94, 0.4));
        }
        
        /* Input fields */
        .stTextInput>div>div>input {
            background-color: #111827 !important;
            color: #F9FAFB !important;
            border-radius: 12px !important;
            border: 2px solid #374151 !important;
            padding: 14px 16px !important;
            font-size: 15px !important;
            transition: all 0.3s ease !important;
        }
        
        .stTextInput>div>div>input:focus {
            border-color: #22C55E !important;
            box-shadow: 0 0 0 3px rgba(34, 197, 94, 0.15) !important;
            background-color: #1F2937 !important;
        }
        
        .stTextInput>div>div>input::placeholder {
            color: #6B7280 !important;
        }
        
        .stTextInput label {
            color: #D1D5DB !important;
            font-weight: 600 !important;
            font-size: 14px !important;
            margin-bottom: 8px !important;
        }
        
        /* Login button - Primary green theme - All variations */
        .stButton>button[kind="primary"],
        .stButton>button[type="primary"],
        button[kind="formSubmit"],
        .stFormSubmitButton>button,
        .stForm button[type="submit"] {
            width: 100% !important;
            background: linear-gradient(135deg, #22C55E 0%, #16A34A 100%) !important;
            color: white !important;
            border: none !important;
            padding: 14px 24px !important;
            border-radius: 12px !important;
            font-size: 16px !important;
            font-weight: 700 !important;
            cursor: pointer !important;
            transition: all 0.3s ease !important;
            box-shadow: 0 4px 15px rgba(34, 197, 94, 0.3) !important;
            text-transform: uppercase !important;
            letter-spacing: 0.5px !important;
        }
        
        .stButton>button[kind="primary"]:hover,
        .stButton>button[type="primary"]:hover,
        button[kind="formSubmit"]:hover,
        .stFormSubmitButton>button:hover,
        .stForm button[type="submit"]:hover {
            transform: translateY(-2px) !important;
            box-shadow: 0 8px 25px rgba(34, 197, 94, 0.4) !important;
            background: linear-gradient(135deg, #16A34A 0%, #15803D 100%) !important;
        }
        
        .stButton>button[kind="primary"]:active,
        .stButton>button[type="primary"]:active,
        button[kind="formSubmit"]:active,
        .stFormSubmitButton>button:active,
        .stForm button[type="submit"]:active {
            transform: translateY(0px) !important;
        }
        
        /* Sign up button - Secondary style (outside form) */
        div[data-testid="column"] > div > div > button:not([kind="formSubmit"]),
        .stButton>button:not([kind="primary"]):not([type="primary"]):not([kind="formSubmit"]) {
            width: 100%;
            background: transparent !important;
            color: #22C55E !important;
            border: 2px solid #22C55E !important;
            padding: 12px 24px !important;
            border-radius: 12px !important;
            font-size: 15px !important;
            font-weight: 600 !important;
            cursor: pointer !important;
            transition: all 0.3s ease !important;
        }
        
        div[data-testid="column"] > div > div > button:not([kind="formSubmit"]):hover,
        .stButton>button:not([kind="primary"]):not([type="primary"]):not([kind="formSubmit"]):hover {
            background: rgba(34, 197, 94, 0.1) !important;
            transform: translateY(-1px) !important;
            box-shadow: 0 4px 12px rgba(34, 197, 94, 0.2) !important;
        }
        
        /* Form styling */
        .stForm {
            background: transparent !important;
            border: none !important;
            padding: 0 !important;
        }
        
        /* Expander for demo credentials */
        .streamlit-expanderHeader {
            background-color: rgba(17, 24, 39, 0.6) !important;
            border-radius: 10px !important;
            border: 1px solid #374151 !important;
            color: #9CA3AF !important;
            font-size: 13px !important;
            padding: 12px 16px !important;
        }
        
        .streamlit-expanderHeader:hover {
            background-color: rgba(31, 41, 55, 0.8) !important;
            border-color: #22C55E !important;
        }
        
        .demo-creds {
            background: rgba(17, 24, 39, 0.8);
            padding: 18px;
            border-radius: 10px;
            margin-top: 4px;
            font-size: 13px;
            color: #9CA3AF;
            border: 1px solid #374151;
            line-height: 1.8;
        }
        
        .demo-creds strong {
            color: #22C55E;
            font-weight: 600;
        }
        
        /* Signup section */
        .signup-section {
            text-align: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #374151;
        }
        
        .signup-text {
            color: #9CA3AF;
            font-size: 14px;
            margin-bottom: 12px;
        }
        
        /* Alert messages */
        .stAlert {
            border-radius: 10px !important;
            border-left: 4px solid #22C55E !important;
        }
        
        /* Divider */
        hr {
            border: none;
            height: 1px;
            background: linear-gradient(90deg, transparent, #374151, transparent);
            margin: 25px 0;
        }
        
        /* Markdown text color */
        div[data-testid="stMarkdownContainer"] p {
            color: #D1D5DB;
        }
        
        /* Hide Streamlit branding */
        #MainMenu {visibility: hidden;}
        footer {visibility: hidden;}
        header {visibility: hidden;}
        </style>
    """, unsafe_allow_html=True)
    
    # Center the login form
    col1, col2, col3 = st.columns([1, 2.5, 1])
    
    with col2:
        # Logo with animation
        st.markdown("<div class='logo-container'>🌾</div>", unsafe_allow_html=True)
        
        # Title
        st.markdown("<div class='login-title'>AgriSaathi</div>", unsafe_allow_html=True)
        st.markdown("<div class='login-subtitle'>Your Agricultural Companion</div>", unsafe_allow_html=True)
        
        # Login form
        with st.form("login_form", clear_on_submit=False):
            username = st.text_input("Username", placeholder="Enter your username", key="username")
            password = st.text_input("Password", type="password", placeholder="Enter your password", key="password")
            
            st.markdown("<br>", unsafe_allow_html=True)
            
            # Single login button
            login_button = st.form_submit_button("🔐 Login", use_container_width=True)
            
            if login_button:
                if username and password:
                    if check_credentials(username, password):
                        st.session_state.logged_in = True
                        st.session_state.username = username
                        st.success("✅ Login successful! Welcome to AgriSaathi.")
                        st.rerun()
                    else:
                        st.error("❌ Invalid username or password. Please try again.")
                else:
                    st.warning("⚠️ Please enter both username and password.")
        
        # Signup section
        st.markdown("<div class='signup-section'>", unsafe_allow_html=True)
        st.markdown("<div class='signup-text'>Don't have an account?</div>", unsafe_allow_html=True)
        if st.button("📝 Create New Account", use_container_width=True, key="goto_signup"):
            st.session_state.show_signup = True
            st.rerun()
        st.markdown("</div>", unsafe_allow_html=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # Demo credentials info
        with st.expander("ℹ️ Demo Credentials for Testing"):
            st.markdown("""
                <div class='demo-creds'>
                    <strong>🎯 Test Accounts Available:</strong><br><br>
                    🔹 <strong>Admin Access:</strong><br>
                    &nbsp;&nbsp;&nbsp;Username: <strong>admin</strong> | Password: <strong>admin123</strong><br><br>
                    🔹 <strong>Farmer Access:</strong><br>
                    &nbsp;&nbsp;&nbsp;Username: <strong>farmer</strong> | Password: <strong>farmer123</strong><br><br>
                    🔹 <strong>Demo Access:</strong><br>
                    &nbsp;&nbsp;&nbsp;Username: <strong>demo</strong> | Password: <strong>demo123</strong>
                </div>
            """, unsafe_allow_html=True)

def logout():
    """Handle logout"""
    st.session_state.logged_in = False
    st.session_state.username = None
    st.rerun()

def is_logged_in():
    """Check if user is logged in"""
    return st.session_state.get('logged_in', False)

def get_username():
    """Get current username"""
    return st.session_state.get('username', 'Guest')
