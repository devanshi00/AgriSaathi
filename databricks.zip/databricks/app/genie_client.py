"""
Genie Client for Databricks AI Assistant Integration
Handles conversation creation, message sending, and polling for results
"""
from databricks.sdk import WorkspaceClient
import time

class GenieClient:
    def __init__(self, space_id: str):
        """
        Initialize Genie client with a space ID.
        
        Args:
            space_id: The Genie space ID from your Databricks workspace
        """
        self.w = WorkspaceClient()
        self.space_id = space_id

    def ask_question(self, question: str, timeout: int = 180, poll_interval: int = 3) -> dict:
        """
        Ask Genie a question and poll for result.
        
        Args:
            question: The natural language question to ask
            timeout: Maximum seconds to wait for response (default: 180)
            poll_interval: Seconds between status polls (default: 3)
            
        Returns:
            dict with keys:
                - status: "success" or "error"
                - content: Natural language response
                - query_result: Dict with "data" and "columns" if SQL was executed
                - sql: The generated SQL query (if applicable)
                - error: Error message (if status is "error")
        """
        try:
            print(f"[GenieClient] Starting conversation for: {question[:50]}...")

            # Start conversation with the question
            response = self.w.genie.start_conversation(
                space_id=self.space_id,
                content=question
            )

            conversation_id = response.conversation_id
            message_id = response.message_id

            print(f"[GenieClient] Conversation started: {conversation_id}")
            print(f"[GenieClient] Message ID: {message_id}")

            # Poll for completion
            start_time = time.time()
            poll_count = 0
            last_status = None

            while time.time() - start_time < timeout:
                poll_count += 1
                elapsed = int(time.time() - start_time)

                msg_status = self.w.genie.get_message(
                    space_id=self.space_id,
                    conversation_id=conversation_id,
                    message_id=message_id
                )

                current_status = str(msg_status.status)

                # Log status changes
                if current_status != last_status:
                    print(f"[GenieClient] Poll #{poll_count} ({elapsed}s): Status = {current_status}")
                    last_status = current_status

                # Check for completion
                if current_status == "COMPLETED":
                    print(f"[GenieClient] Query COMPLETED after {elapsed}s")

                    result = {
                        "conversation_id": conversation_id,
                        "message_id": message_id,
                        "status": "success",
                        "content": msg_status.content or "Query executed successfully.",
                        "attachments": []
                    }

                    # Extract SQL and query results if available
                    if getattr(msg_status, "attachments", None):
                        for att in msg_status.attachments:
                            att_dict = {"type": getattr(att, "type", None)}

                            if getattr(att, "query", None):
                                if getattr(att.query, "query", None):
                                    result["sql"] = att.query.query
                                    att_dict["sql"] = att.query.query

                                if getattr(att.query, "result", None):
                                    columns = []
                                    schema = getattr(att.query.result, "schema", None)
                                    if schema and getattr(schema, "columns", None):
                                        columns = [col.name for col in schema.columns]

                                    data = getattr(att.query.result, "data_array", []) or []

                                    result["query_result"] = {
                                        "columns": columns,
                                        "data": data
                                    }

                            result["attachments"].append(att_dict)

                    return result

                # Check for failure
                if current_status in {"FAILED", "CANCELLED"}:
                    error_msg = getattr(msg_status, "error", f"Query {current_status.lower()}")
                    print(f"[GenieClient] Query {current_status}: {error_msg}")
                    return {
                        "status": "error",
                        "error": error_msg
                    }

                # Continue polling for intermediate states (EXECUTING, COMPILING, QUEUED, etc.)
                time.sleep(poll_interval)

            # Timeout reached
            print(f"[GenieClient] TIMEOUT after {timeout}s (last status: {last_status})")
            return {
                "status": "error",
                "error": f"Timeout after {timeout}s. Last status: {last_status}"
            }

        except Exception as e:
            import traceback
            error_trace = traceback.format_exc()
            print(f"[GenieClient] ERROR:\n{error_trace}")
            return {"status": "error", "error": str(e)}
