"""
Weather Predictions Module
7-day weather forecasts for precision agriculture
"""
import streamlit as st
import plotly.graph_objects as go
import pandas as pd
from datetime import datetime, timedelta
import random

def show_weather_predictions():
    """Display weather forecasts and farming recommendations with enhanced UI"""
    
    # Enhanced dark theme CSS for weather page
    st.markdown("""
    <style>
    /* Weather header with gradient */
    .weather-header {
        background: linear-gradient(135deg, #0ea5e9 0%, #3b82f6 100%);
        color: white;
        padding: 32px;
        border-radius: 20px;
        margin-bottom: 24px;
        box-shadow: 0 8px 24px rgba(14, 165, 233, 0.3);
        text-align: center;
    }
    
    .weather-header h2 {
        margin: 0 0 8px 0;
        font-size: 36px;
        font-weight: 800;
    }
    
    .weather-header p {
        margin: 0;
        font-size: 16px;
        opacity: 0.9;
    }
    
    /* Current weather card */
    .current-weather-card {
        background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
        border-radius: 20px;
        padding: 32px;
        margin: 24px 0;
        border: 2px solid #475569;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
    }
    
    .weather-icon-large {
        font-size: 80px;
        text-align: center;
        margin-bottom: 16px;
        animation: float 3s ease-in-out infinite;
    }
    
    @keyframes float {
        0%, 100% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
    }
    
    .current-temp {
        font-size: 56px;
        font-weight: 800;
        text-align: center;
        color: #f1f5f9;
        margin: 0;
        text-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
    }
    
    .current-condition {
        font-size: 20px;
        text-align: center;
        color: #cbd5e1;
        margin: 8px 0 0 0;
        font-weight: 500;
    }
    
    /* Metric cards */
    .metric-card {
        background: linear-gradient(135deg, #1e293b 0%, #252936 100%);
        border-radius: 16px;
        padding: 20px;
        text-align: center;
        border: 1px solid #3f4556;
        transition: all 0.3s ease;
        height: 100%;
    }
    
    .metric-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 20px rgba(59, 130, 246, 0.3);
        border-color: #3b82f6;
    }
    
    .metric-icon {
        font-size: 32px;
        margin-bottom: 8px;
    }
    
    .metric-value {
        font-size: 28px;
        font-weight: 700;
        color: #f1f5f9;
        margin: 8px 0;
    }
    
    .metric-label {
        font-size: 14px;
        color: #94a3b8;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    /* Forecast table styling */
    .forecast-table {
        background: linear-gradient(135deg, #1e293b 0%, #252936 100%);
        border-radius: 16px;
        padding: 24px;
        border: 1px solid #3f4556;
        margin: 24px 0;
    }
    
    /* Section headers */
    .section-header {
        color: #f1f5f9;
        font-size: 24px;
        font-weight: 700;
        margin: 32px 0 16px 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .section-header::before {
        content: '';
        width: 4px;
        height: 28px;
        background: linear-gradient(180deg, #3b82f6 0%, #0ea5e9 100%);
        border-radius: 4px;
    }
    
    /* Recommendation cards */
    .recommendation-card {
        background: linear-gradient(135deg, #1e293b 0%, #252936 100%);
        border-radius: 16px;
        padding: 24px;
        border: 1px solid #3f4556;
        height: 100%;
    }
    
    .recommendation-card.good {
        border-left: 4px solid #10b981;
    }
    
    .recommendation-card.avoid {
        border-left: 4px solid #f59e0b;
    }
    
    .recommendation-card h4 {
        color: #f1f5f9;
        font-size: 18px;
        margin: 0 0 16px 0;
    }
    
    .recommendation-card ul {
        color: #cbd5e1;
        margin: 0;
        padding-left: 20px;
    }
    
    .recommendation-card li {
        margin: 8px 0;
        line-height: 1.6;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Header
    st.markdown("""
    <div class="weather-header">
        <h2>🌤️ Weather Forecast</h2>
        <p>AI-powered 7-day weather predictions for precision agriculture</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Location selector
    col1, col2 = st.columns([3, 1])
    with col1:
        location = st.selectbox("📍 Select Your Location", 
            ["Mumbai, Maharashtra", "Delhi, NCR", "Bangalore, Karnataka", 
             "Chennai, Tamil Nadu", "Kolkata, West Bengal", "Pune, Maharashtra"],
            help="Choose your farming location for accurate weather forecasts")
    with col2:
        unit = st.selectbox("🌡️ Unit", ["Celsius (°C)", "Fahrenheit (°F)"])
    
    st.markdown("")
    
    # Current weather - Enhanced layout
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("""
        <div class="current-weather-card">
            <div class="weather-icon-large">☀️</div>
            <h1 class="current-temp">28°C</h1>
            <p class="current-condition">Sunny & Clear</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        # Weather metrics in a grid
        metric_col1, metric_col2 = st.columns(2)
        
        with metric_col1:
            st.markdown("""
            <div class="metric-card">
                <div class="metric-icon">💧</div>
                <div class="metric-value">65%</div>
                <div class="metric-label">Humidity</div>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown("")
            
            st.markdown("""
            <div class="metric-card">
                <div class="metric-icon">💨</div>
                <div class="metric-value">12 km/h</div>
                <div class="metric-label">Wind Speed</div>
            </div>
            """, unsafe_allow_html=True)
        
        with metric_col2:
            st.markdown("""
            <div class="metric-card">
                <div class="metric-icon">🌧️</div>
                <div class="metric-value">15%</div>
                <div class="metric-label">Rain Chance</div>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown("")
            
            st.markdown("""
            <div class="metric-card">
                <div class="metric-icon">🌅</div>
                <div class="metric-value">6:12 AM</div>
                <div class="metric-label">Sunrise</div>
            </div>
            """, unsafe_allow_html=True)
    
    # 7-day forecast
    st.markdown('<h3 class="section-header">📅 7-Day Detailed Forecast</h3>', unsafe_allow_html=True)
    
    forecast_data = []
    for i in range(7):
        date = datetime.now() + timedelta(days=i)
        temp_max = random.randint(26, 35)
        temp_min = random.randint(18, 25)
        rain = random.randint(0, 80)
        conditions = ["☀️ Sunny", "⛅ Partly Cloudy", "☁️ Cloudy", "🌧️ Rain", "⛈️ Thunderstorm"]
        condition = random.choice(conditions)
        
        forecast_data.append({
            "Date": date.strftime("%a, %d %b"),
            "Condition": condition,
            "High": f"{temp_max}°C",
            "Low": f"{temp_min}°C",
            "Rain": f"{rain}%",
            "Humidity": f"{random.randint(50, 85)}%"
        })
    
    forecast_df = pd.DataFrame(forecast_data)
    
    # Style the dataframe
    st.dataframe(
        forecast_df,
        use_container_width=True,
        hide_index=True,
        height=280
    )
    
    # Temperature trend chart with enhanced styling
    st.markdown('<h3 class="section-header">📈 Temperature Trend Analysis</h3>', unsafe_allow_html=True)
    
    temps_high = [random.randint(28, 35) for _ in range(7)]
    temps_low = [random.randint(18, 25) for _ in range(7)]
    dates = [(datetime.now() + timedelta(days=i)).strftime("%a") for i in range(7)]
    
    fig = go.Figure()
    
    # Add high temperature line
    fig.add_trace(go.Scatter(
        x=dates, y=temps_high,
        mode='lines+markers',
        name='High',
        line=dict(color="#ef4444", width=3),
        marker=dict(size=10, color="#ef4444"),
        fill='tonexty',
        fillcolor='rgba(239, 68, 68, 0.1)'
    ))
    
    # Add low temperature line
    fig.add_trace(go.Scatter(
        x=dates, y=temps_low,
        mode='lines+markers',
        name='Low',
        line=dict(color="#3b82f6", width=3),
        marker=dict(size=10, color="#3b82f6"),
        fill='tozeroy',
        fillcolor='rgba(59, 130, 246, 0.1)'
    ))
    
    fig.update_layout(
        height=350,
        xaxis_title="Day",
        yaxis_title="Temperature (°C)",
        template="plotly_dark",
        hovermode="x unified",
        paper_bgcolor='rgba(30, 41, 59, 0.5)',
        plot_bgcolor='rgba(30, 41, 59, 0.5)',
        font=dict(color='#e2e8f0'),
        showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Farming recommendations with enhanced cards
    st.markdown('<h3 class="section-header">🌾 Smart Farming Recommendations</h3>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        <div class="recommendation-card good">
            <h4>✅ Recommended Activities</h4>
            <ul>
                <li><strong>Irrigation:</strong> Best time 6 AM - 9 AM</li>
                <li><strong>Fertilizer Application:</strong> Optimal soil moisture</li>
                <li><strong>Harvesting:</strong> Dry conditions favorable</li>
                <li><strong>Planting:</strong> Good germination weather</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="recommendation-card avoid">
            <h4>⚠️ Activities to Avoid</h4>
            <ul>
                <li><strong>Pesticide Spraying:</strong> Windy conditions expected</li>
                <li><strong>Heavy Machinery:</strong> Possible soil compaction</li>
                <li><strong>Outdoor Storage:</strong> Rain risk in 3 days</li>
                <li><strong>Late Evening Work:</strong> Dew formation likely</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
