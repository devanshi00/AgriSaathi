"""
AgriSaathi Home Page — Four Key Agricultural Intelligence Tabs
Plant Disease · Schemes Portal · Mandi Stats · Genie AI Chat
"""
import streamlit as st

# Import tab modules
from disease_detection import show_disease_detection
# from weather_predictions import show_weather_predictions
from schemes_summary import show_schemes_summary
from mandi_prices import show_mandi_prices
from genie_chat import show_genie_chat

def show_home_page():
    """Main home page with four intelligence tabs - Dark Theme"""
    
    # Apply dark theme CSS
    st.markdown("""
        <style>
        /* Dark Theme - Tab styling */
        .stTabs [data-baseweb="tab-list"] {
            gap: 16px;
            background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%);
            padding: 12px 24px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(30, 58, 138, 0.3);
        }
        
        .stTabs [data-baseweb="tab"] {
            color: #94a3b8;
            font-weight: 600;
            font-size: 15px;
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        
        .stTabs [data-baseweb="tab"]:hover {
            color: #cbd5e1;
            background: rgba(255, 255, 255, 0.1);
        }
        
        .stTabs [aria-selected="true"] {
            background: rgba(255, 255, 255, 0.15);
            color: #ffffff;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }
        
        /* Dark Info cards */
        .info-card {
            background: linear-gradient(135deg, #1e2530 0%, #2d3748 100%);
            border: 2px solid #374151;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }
        
        .info-card:hover {
            border-color: #3b82f6;
            box-shadow: 0 8px 24px rgba(59, 130, 246, 0.25);
            transform: translateY(-2px);
            transition: all 0.3s ease;
        }
        
        .card-title {
            color: #60a5fa;
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 12px;
        }
        
        .card-stat {
            color: #22d3ee;
            font-size: 32px;
            font-weight: 700;
            margin: 8px 0;
        }
        
        /* Alert boxes - Dark */
        .disease-alert {
            background: linear-gradient(135deg, #7f1d1d 0%, #991b1b 100%);
            border-left: 4px solid #ef4444;
            padding: 16px;
            border-radius: 8px;
            margin: 12px 0;
            color: #fecaca;
        }
        
        .disease-warning {
            background: linear-gradient(135deg, #78350f 0%, #92400e 100%);
            border-left: 4px solid #f59e0b;
            padding: 16px;
            border-radius: 8px;
            margin: 12px 0;
            color: #fde68a;
        }
        
        .disease-safe {
            background: linear-gradient(135deg, #064e3b 0%, #065f46 100%);
            border-left: 4px solid #10b981;
            padding: 16px;
            border-radius: 8px;
            margin: 12px 0;
            color: #a7f3d0;
        }
        
        .weather-icon {
            font-size: 48px;
            text-align: center;
        }
        
        /* Title styling - compact */
        .main h1 {
            color: #f8fafc !important;
            font-size: 2rem !important;
            margin-bottom: 0.5rem !important;
        }
        
        /* Language badge styling */
        .language-badge {
            display: inline-block !important;
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%) !important;
            color: white !important;
            padding: 4px 12px !important;
            border-radius: 12px !important;
            font-size: 12px !important;
            font-weight: 600 !important;
            margin-right: 8px !important;
        }
        </style>
    """, unsafe_allow_html=True)
    
    st.title("🏠 AgriSaathi Intelligence Hub")
    
    # Create four tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "🌿 Plant Disease Detection",
        "🌱 Schemes Portal",
        "📊 Mandi Price Stats",
        "🤖 Genie AI Chat"
    ])
    
    # Render each tab using the modular files
    with tab1:
        show_disease_detection()
    
    with tab2:
        show_schemes_summary()
    
    with tab3:
        show_mandi_prices()
    
    with tab4:
        show_genie_chat()
