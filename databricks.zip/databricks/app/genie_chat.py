"""
Genie AI Chat Interface Module
Interactive chatbot powered by Databricks Genie AI with voice integration
"""
import streamlit as st

def generate_genie_response(query):
    """Generate response using Databricks Genie AI from session state"""
    genie = st.session_state.get('genie_client')
    
    if genie is None:
        return "❌ Genie AI unavailable. Please check configuration."
    
    try:
        # Increased timeout to 180 seconds
        result = genie.ask_question(query, timeout=180)
        
        if result.get("status") == "error":
            return f"❌ Error: {result.get('error', 'Unknown error')}"
        
        response = result.get("content", "Query completed.")
        
        if "sql" in result:
            response += f"\n\n**SQL:**\n```sql\n{result['sql']}\n```"
        
        if "query_result" in result:
            qr = result["query_result"]
            if qr.get("data") and len(qr["data"]) > 0:
                response += f"\n\n**Results:** {len(qr['data'])} rows"
                if qr.get("columns"):
                    response += "\n**Preview:**"
                    for i, row in enumerate(qr["data"][:5], 1):
                        response += f"\n{i}. {' | '.join(str(v) for v in row)}"
        
        return response
        
    except Exception as e:
        if "timeout" in str(e).lower():
            return "⏱️ Request timeout. The query took too long. Try a simpler question or check the logs."
        return f"❌ Error: {str(e)}"

def show_genie_chat():
    """Display Genie AI chatbot with voice integration"""
    
    # Initialize session state
    if "chat_messages" not in st.session_state:
        st.session_state.chat_messages = [
            {"role": "assistant", "content": "👋 Hello! I'm your AgriSaathi AI assistant powered by Genie AI. Ask me about diseases, schemes, or agricultural data!"}
        ]
    
    # Get voice settings and functions from session state
    selected_language = st.session_state.get('selected_language', 'en-IN')
    enable_tts = st.session_state.get('enable_tts', True)
    sarvam_speech_to_text = st.session_state.get('sarvam_speech_to_text')
    sarvam_text_to_speech = st.session_state.get('sarvam_text_to_speech')
    
    # Language badge
    voice_lang_display = "हिंदी (Hindi)" if selected_language == "hi-IN" else "English (India)"
    st.markdown(f"**Status:** <span class='language-badge'>{voice_lang_display}</span>", unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Voice input section
    st.markdown("### 🎤 Voice Input")
    
    audio_file = st.file_uploader(
        "Upload audio file (MP3, WAV, M4A):",
        type=['mp3', 'wav', 'm4a', 'ogg'],
        help="Record your question in Hindi or English",
        key="genie_audio_uploader"
    )
    
    if audio_file is not None and sarvam_speech_to_text is not None:
        # Play uploaded audio
        st.audio(audio_file, format=f'audio/{audio_file.type.split("/")[-1]}')
        
        with st.spinner("🔄 Processing speech with Sarvam AI..."):
            audio_bytes = audio_file.read()
            transcript = sarvam_speech_to_text(audio_bytes, selected_language)
            
            if transcript and not transcript.startswith("Error"):
                st.success(f"✅ **Transcribed:** {transcript}")
                
                # Add to chat
                st.session_state.chat_messages.append({"role": "user", "content": f"🎤 {transcript}"})
                
                # Generate response
                with st.spinner("🤖 Generating response..."):
                    response = generate_genie_response(transcript)
                    st.session_state.chat_messages.append({"role": "assistant", "content": response})
                
                # Text-to-speech (if enabled)
                if enable_tts and sarvam_text_to_speech is not None:
                    with st.spinner("🔊 Generating voice response..."):
                        speaker = "priya" if "hi" in selected_language else "rahul"
                        audio_response = sarvam_text_to_speech(
                            response[:500],
                            selected_language,
                            speaker=speaker
                        )
                        if audio_response:
                            st.audio(audio_response, format='audio/wav')
            else:
                st.error(f"❌ {transcript}")
    
    st.markdown("---")
    
    # Display chat messages
    for msg in st.session_state.chat_messages:
        with st.chat_message(msg["role"], avatar="🧑‍🌾" if msg["role"] == "user" else "🤖"):
            st.markdown(msg["content"])
    
    # Text chat input
    if prompt := st.chat_input("💬 Ask me anything about agriculture..."):
        # Add user message
        st.session_state.chat_messages.append({"role": "user", "content": prompt})
        with st.chat_message("user", avatar="🧑‍🌾"):
            st.markdown(prompt)
        
        # Generate response
        with st.chat_message("assistant", avatar="🤖"):
            with st.spinner("Thinking..."):
                response = generate_genie_response(prompt)
                st.markdown(response)
                st.session_state.chat_messages.append({"role": "assistant", "content": response})
                
                # Optional TTS for text input
                if enable_tts and sarvam_text_to_speech is not None:
                    with st.spinner("🔊 Generating voice..."):
                        speaker = "priya" if "hi" in selected_language else "rahul"
                        audio_response = sarvam_text_to_speech(
                            response[:500],
                            selected_language,
                            speaker=speaker
                        )
                        if audio_response:
                            st.audio(audio_response, format='audio/wav')
