import streamlit as st
import json
import os
import re

def save_user(username, password, email, full_name, location, aadhar_card):
    """
    Save new user credentials to a JSON file.
    In production, use a secure database with hashed passwords.
    """
    users_file = "users.json"
    
    # Load existing users
    if os.path.exists(users_file):
        with open(users_file, 'r') as f:
            users = json.load(f)
    else:
        users = {
            "admin": {"password": "admin123", "email": "admin@agrisaathi.com", "full_name": "Admin User", "location": "Delhi", "aadhar_card": "123456789012"},
            "farmer": {"password": "farmer123", "email": "farmer@agrisaathi.com", "full_name": "Farmer User", "location": "Punjab", "aadhar_card": "234567890123"},
            "demo": {"password": "demo123", "email": "demo@agrisaathi.com", "full_name": "Demo User", "location": "Maharashtra", "aadhar_card": "345678901234"}
        }
    
    # Add new user
    users[username] = {
        "password": password,
        "email": email,
        "full_name": full_name,
        "location": location,
        "aadhar_card": aadhar_card
    }
    
    # Save to file
    with open(users_file, 'w') as f:
        json.dump(users, f, indent=4)
    
    return True

def username_exists(username):
    """Check if username already exists"""
    users_file = "users.json"
    
    if os.path.exists(users_file):
        with open(users_file, 'r') as f:
            users = json.load(f)
        return username in users
    else:
        # Check default users
        default_users = ["admin", "farmer", "demo"]
        return username in default_users

def validate_aadhar(aadhar):
    """Validate Aadhar card number (12 digits)"""
    # Remove spaces and hyphens
    aadhar = aadhar.replace(" ", "").replace("-", "")
    # Check if it's exactly 12 digits
    return bool(re.match(r'^\d{12}$', aadhar))

def show_signup_page():
    """Display an appealing green-themed signup page"""
    
    # Custom CSS for green dark theme styling matching login page
    st.markdown("""
        <style>
        /* Main background gradient */
        .main {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%);
            min-height: 100vh;
        }
        
        /* Animated background */
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
        }
        
        /* Signup container */
        .signup-container {
            background: rgba(31, 41, 55, 0.8);
            backdrop-filter: blur(10px);
            padding: 45px 40px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5), 0 0 40px rgba(34, 197, 94, 0.1);
            max-width: 550px;
            margin: 40px auto;
            border: 1px solid rgba(34, 197, 94, 0.2);
            animation: fadeIn 0.6s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Title styling */
        .signup-title {
            color: #22C55E;
            text-align: center;
            font-size: 38px;
            font-weight: 800;
            margin-bottom: 8px;
            text-shadow: 0 0 20px rgba(34, 197, 94, 0.3);
            letter-spacing: -0.5px;
        }
        
        .signup-subtitle {
            color: #9CA3AF;
            text-align: center;
            font-size: 15px;
            margin-bottom: 30px;
            font-weight: 400;
        }
        
        /* Logo container with glow effect */
        .logo-container {
            text-align: center;
            font-size: 65px;
            margin-bottom: 20px;
            animation: float 3s ease-in-out infinite;
            filter: drop-shadow(0 0 20px rgba(34, 197, 94, 0.4));
        }
        
        /* Input fields */
        .stTextInput>div>div>input {
            background-color: #111827 !important;
            color: #F9FAFB !important;
            border-radius: 12px !important;
            border: 2px solid #374151 !important;
            padding: 13px 16px !important;
            font-size: 14px !important;
            transition: all 0.3s ease !important;
        }
        
        .stTextInput>div>div>input:focus {
            border-color: #22C55E !important;
            box-shadow: 0 0 0 3px rgba(34, 197, 94, 0.15) !important;
            background-color: #1F2937 !important;
        }
        
        .stTextInput>div>div>input::placeholder {
            color: #6B7280 !important;
        }
        
        .stTextInput label {
            color: #D1D5DB !important;
            font-weight: 600 !important;
            font-size: 13px !important;
            margin-bottom: 6px !important;
        }
        
        /* Selectbox styling */
        .stSelectbox>div>div>div {
            background-color: #111827 !important;
            color: #F9FAFB !important;
            border-radius: 12px !important;
            border: 2px solid #374151 !important;
        }
        
        .stSelectbox label {
            color: #D1D5DB !important;
            font-weight: 600 !important;
            font-size: 13px !important;
            margin-bottom: 6px !important;
        }
        
        /* Create Account button - Primary green theme */
        .stButton>button[kind="primary"],
        .stButton>button[type="primary"],
        button[kind="formSubmit"],
        .stFormSubmitButton>button,
        .stForm button[type="submit"] {
            width: 100% !important;
            background: linear-gradient(135deg, #22C55E 0%, #16A34A 100%) !important;
            color: white !important;
            border: none !important;
            padding: 14px 24px !important;
            border-radius: 12px !important;
            font-size: 16px !important;
            font-weight: 700 !important;
            cursor: pointer !important;
            transition: all 0.3s ease !important;
            box-shadow: 0 4px 15px rgba(34, 197, 94, 0.3) !important;
            text-transform: uppercase !important;
            letter-spacing: 0.5px !important;
        }
        
        .stButton>button[kind="primary"]:hover,
        .stButton>button[type="primary"]:hover,
        button[kind="formSubmit"]:hover,
        .stFormSubmitButton>button:hover,
        .stForm button[type="submit"]:hover {
            transform: translateY(-2px) !important;
            box-shadow: 0 8px 25px rgba(34, 197, 94, 0.4) !important;
            background: linear-gradient(135deg, #16A34A 0%, #15803D 100%) !important;
        }
        
        .stButton>button[kind="primary"]:active,
        .stButton>button[type="primary"]:active,
        button[kind="formSubmit"]:active,
        .stFormSubmitButton>button:active,
        .stForm button[type="submit"]:active {
            transform: translateY(0px) !important;
        }
        
        /* Back to Login button - Secondary style */
        .stButton>button:not([kind="primary"]):not([type="primary"]):not([kind="formSubmit"]) {
            width: 100%;
            background: transparent !important;
            color: #22C55E !important;
            border: 2px solid #22C55E !important;
            padding: 12px 24px !important;
            border-radius: 12px !important;
            font-size: 14px !important;
            font-weight: 600 !important;
            cursor: pointer !important;
            transition: all 0.3s ease !important;
        }
        
        .stButton>button:not([kind="primary"]):not([type="primary"]):not([kind="formSubmit"]):hover {
            background: rgba(34, 197, 94, 0.1) !important;
            transform: translateY(-1px) !important;
            box-shadow: 0 4px 12px rgba(34, 197, 94, 0.2) !important;
        }
        
        /* Form styling */
        .stForm {
            background: transparent !important;
            border: none !important;
            padding: 0 !important;
        }
        
        /* Alert messages */
        .stAlert {
            border-radius: 10px !important;
            border-left: 4px solid #22C55E !important;
            font-size: 14px !important;
        }
        
        /* Success message */
        .stSuccess {
            background-color: rgba(34, 197, 94, 0.1) !important;
            color: #22C55E !important;
            border-left-color: #22C55E !important;
        }
        
        /* Error message */
        .stError {
            background-color: rgba(239, 68, 68, 0.1) !important;
            color: #EF4444 !important;
            border-left-color: #EF4444 !important;
        }
        
        /* Back link section */
        .back-section {
            text-align: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #374151;
        }
        
        /* Divider */
        hr {
            border: none;
            height: 1px;
            background: linear-gradient(90deg, transparent, #374151, transparent);
            margin: 20px 0;
        }
        
        /* Markdown text color */
        div[data-testid="stMarkdownContainer"] p {
            color: #D1D5DB;
        }
        
        /* Hide Streamlit branding */
        #MainMenu {visibility: hidden;}
        footer {visibility: hidden;}
        header {visibility: hidden;}
        </style>
    """, unsafe_allow_html=True)
    
    # Indian states list
    indian_states = [
        "Select State",
        "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
        "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka",
        "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram",
        "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu",
        "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
        "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu",
        "Delhi", "Jammu and Kashmir", "Ladakh", "Lakshadweep", "Puducherry"
    ]
    
    # Center the signup form
    col1, col2, col3 = st.columns([1, 3, 1])
    
    with col2:
        # Logo with animation
        st.markdown("<div class='logo-container'>🌾</div>", unsafe_allow_html=True)
        
        # Title
        st.markdown("<div class='signup-title'>Join AgriSaathi</div>", unsafe_allow_html=True)
        st.markdown("<div class='signup-subtitle'>Create your account to get started</div>", unsafe_allow_html=True)
        
        # Signup form
        with st.form("signup_form", clear_on_submit=False):
            full_name = st.text_input("Full Name", placeholder="Enter your full name", key="signup_full_name")
            email = st.text_input("Email Address", placeholder="your.email@example.com", key="signup_email")
            
            # Location field
            location = st.selectbox("State / Location", indian_states, key="signup_location")
            
            # Aadhar card field
            aadhar_card = st.text_input("Aadhar Card Number", placeholder="Enter 12-digit Aadhar number", key="signup_aadhar", max_chars=12)
            
            username = st.text_input("Username", placeholder="Choose a unique username", key="signup_username")
            
            col_pwd1, col_pwd2 = st.columns(2)
            with col_pwd1:
                password = st.text_input("Password", type="password", placeholder="Min. 6 characters", key="signup_password")
            with col_pwd2:
                confirm_password = st.text_input("Confirm Password", type="password", placeholder="Re-enter password", key="signup_confirm_password")
            
            st.markdown("<br>", unsafe_allow_html=True)
            
            # Create Account button
            signup_button = st.form_submit_button("🚀 Create Account", use_container_width=True)
            
            if signup_button:
                # Validation
                if not all([full_name, email, username, password, confirm_password, location, aadhar_card]):
                    st.error("❌ Please fill in all fields")
                elif location == "Select State":
                    st.error("❌ Please select your state/location")
                elif not validate_aadhar(aadhar_card):
                    st.error("❌ Invalid Aadhar card number. Must be exactly 12 digits")
                elif password != confirm_password:
                    st.error("❌ Passwords do not match")
                elif len(password) < 6:
                    st.error("❌ Password must be at least 6 characters")
                elif username_exists(username):
                    st.error("❌ Username already exists. Please choose another one.")
                elif "@" not in email or "." not in email.split("@")[-1]:
                    st.error("❌ Please enter a valid email address")
                elif len(username) < 3:
                    st.error("❌ Username must be at least 3 characters")
                else:
                    # Clean up aadhar (remove spaces/hyphens)
                    clean_aadhar = aadhar_card.replace(" ", "").replace("-", "")
                    
                    # Save user
                    if save_user(username, password, email, full_name, location, clean_aadhar):
                        st.success("✅ Account created successfully! Redirecting to login...")
                        st.session_state.show_signup = False
                        st.balloons()
                        st.rerun()
                    else:
                        st.error("❌ Error creating account. Please try again.")
        
        # Back to login section
        st.markdown("<div class='back-section'>", unsafe_allow_html=True)
        if st.button("← Back to Login", use_container_width=True, key="back_to_login"):
            st.session_state.show_signup = False
            st.rerun()
        st.markdown("</div>", unsafe_allow_html=True)
