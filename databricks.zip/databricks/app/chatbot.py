"""
AgriSaathi AI Chatbot — Powered by Databricks Genie
Floating chatbot button at bottom right corner with slide-up panel
"""
import streamlit as st

def show_chatbot():
    """Display floating chatbot with working toggle and slide-up panel"""
    
    # Initialize session state
    if "chat_messages" not in st.session_state:
        st.session_state.chat_messages = [
            {"role": "assistant", "content": "👋 Hello! I'm your AgriSaathi AI assistant powered by Genie. I can help you with:\n\n• 🔍 Query agricultural data\n• 📊 Analyze crop statistics\n• 🌾 Scheme recommendations\n• 💰 Market price insights\n\nWhat would you like to know?"}
        ]
    
    if "chat_open" not in st.session_state:
        st.session_state.chat_open = False
    
    # Complete CSS for floating chatbot
    st.markdown("""
    <style>
    /* Hide default Streamlit UI elements for cleaner look */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    
    /* Floating chatbot container at bottom right */
    .floating-chat-container {
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 9999;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    /* Floating chat button */
    .floating-chat-button {
        width: 70px;
        height: 70px;
        border-radius: 50%;
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
        color: white;
        border: 3px solid #1e3a8a;
        box-shadow: 0 8px 24px rgba(59, 130, 246, 0.5);
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 32px;
        transition: all 0.3s ease;
        animation: pulse-btn 2s infinite;
        position: relative;
    }
    
    .floating-chat-button:hover {
        transform: scale(1.1);
        box-shadow: 0 0 40px rgba(59, 130, 246, 0.8);
    }
    
    @keyframes pulse-btn {
        0%, 100% { box-shadow: 0 8px 24px rgba(59, 130, 246, 0.5); }
        50% { box-shadow: 0 8px 40px rgba(59, 130, 246, 0.8); }
    }
    
    /* Chat panel styling */
    .chat-panel {
        position: fixed;
        bottom: 100px;
        right: 20px;
        width: 420px;
        max-width: 90vw;
        max-height: 650px;
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
        border-radius: 16px;
        box-shadow: 0 12px 48px rgba(0, 0, 0, 0.6);
        border: 2px solid #3b82f6;
        z-index: 9998;
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }
    
    /* Chat header */
    .chat-header {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
        color: white;
        padding: 18px 20px;
        border-bottom: 2px solid #1e3a8a;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .chat-header h3 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: white;
    }
    
    /* Chat messages area */
    .chat-messages-area {
        flex: 1;
        overflow-y: auto;
        padding: 16px;
        background: #0f172a;
        max-height: 450px;
    }
    
    /* Message bubbles */
    .message-bubble {
        margin-bottom: 12px;
        padding: 12px 16px;
        border-radius: 12px;
        line-height: 1.6;
    }
    
    .assistant-message {
        background: linear-gradient(135deg, #1a1f2e 0%, #252936 100%);
        border-left: 4px solid #10b981;
        color: #e2e8f0;
    }
    
    .user-message {
        background: linear-gradient(135deg, #2d3748 0%, #1e293b 100%);
        border-left: 4px solid #3b82f6;
        color: #e2e8f0;
        margin-left: 20px;
    }
    
    /* Scrollbar styling */
    .chat-messages-area::-webkit-scrollbar {
        width: 6px;
    }
    
    .chat-messages-area::-webkit-scrollbar-track {
        background: #1e2530;
    }
    
    .chat-messages-area::-webkit-scrollbar-thumb {
        background: #4a5568;
        border-radius: 3px;
    }
    
    /* Input area styling */
    .stChatInput {
        background: #1e293b !important;
        border-top: 2px solid #334155 !important;
    }
    
    .stChatInput input {
        background: #0f172a !important;
        color: #e2e8f0 !important;
        border: 2px solid #334155 !important;
        border-radius: 10px !important;
    }
    
    .stChatInput input:focus {
        border-color: #3b82f6 !important;
    }
    
    /* Dark theme for chat messages */
    .stChatMessage {
        background: transparent !important;
        padding: 0 !important;
    }
    
    [data-testid="stChatMessageContent"] {
        color: #e2e8f0 !important;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Render floating button HTML
    button_html = f"""
    <div class="floating-chat-container">
        <div class="floating-chat-button" onclick="toggleChat()">
            {'✖️' if st.session_state.chat_open else '💬'}
        </div>
    </div>
    
    <script>
    function toggleChat() {{
        // Use Streamlit's component communication
        window.parent.postMessage({{
            type: 'streamlit:setComponentValue',
            value: 'toggle_chat'
        }}, '*');
    }}
    </script>
    """
    
    # Create toggle mechanism using columns (hidden)
    col1, col2 = st.columns([1, 20])
    with col1:
        if st.button("🔄", key="chat_toggle_hidden", help="Toggle Chat"):
            st.session_state.chat_open = not st.session_state.chat_open
            st.rerun()
    
    # Hide the button with CSS
    st.markdown("""
    <style>
    button[kind="secondary"] {
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 70px;
        height: 70px;
        border-radius: 50%;
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%) !important;
        color: white !important;
        border: 3px solid #1e3a8a !important;
        box-shadow: 0 8px 24px rgba(59, 130, 246, 0.5) !important;
        font-size: 32px !important;
        z-index: 9999 !important;
        animation: pulse-btn 2s infinite !important;
    }
    
    button[kind="secondary"]:hover {
        transform: scale(1.1) !important;
        box-shadow: 0 0 40px rgba(59, 130, 246, 0.8) !important;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Show chat panel if open
    if st.session_state.chat_open:
        # Create chat panel using Streamlit container
        with st.container():
            st.markdown("""
            <div class="chat-panel">
                <div class="chat-header">
                    <span>🤖</span>
                    <h3>AgriSaathi AI Assistant</h3>
                </div>
                <div class="chat-messages-area">
            """, unsafe_allow_html=True)
            
            # Display all messages
            for msg in st.session_state.chat_messages:
                role_class = "assistant-message" if msg["role"] == "assistant" else "user-message"
                st.markdown(f"""
                <div class="message-bubble {role_class}">
                    {msg["content"]}
                </div>
                """, unsafe_allow_html=True)
            
            st.markdown("</div></div>", unsafe_allow_html=True)
            
            # Chat input at bottom
            if prompt := st.chat_input("Ask me anything about agriculture...", key="chat_input_field"):
                # Add user message
                st.session_state.chat_messages.append({"role": "user", "content": prompt})
                
                # Generate response
                response = generate_genie_response(prompt)
                st.session_state.chat_messages.append({"role": "assistant", "content": response})
                
                st.rerun()


def generate_genie_response(query):
    """Generate contextual responses using Genie-like intelligence"""
    
    query_lower = query.lower()
    
    # Scheme-related queries
    if any(word in query_lower for word in ["scheme", "yojana", "subsidy", "support"]):
        return """🌾 **Government Schemes Available:**

**PM-KISAN** - ₹6,000/year direct income support
**PMFBY** - Crop insurance with 2% premium
**Kisan Credit Card** - Up to ₹3 lakhs credit at 4% interest
**Soil Health Card** - Free soil testing & recommendations

Would you like details on any specific scheme?"""
    
    # Price-related queries
    elif any(word in query_lower for word in ["price", "rate", "mandi", "market"]):
        return """📊 **Current Market Prices:**

**Wheat**: ₹2,150/quintal (↑ 2.5%)
**Rice**: ₹3,200/quintal (↓ 0.9%)
**Cotton**: ₹6,800/quintal (↑ 3.0%)
**Onion**: ₹1,800/quintal (↑ 7.1%)

Prices are showing an upward trend. Check the Mandi Prices page for detailed forecasts!"""
    
    # Weather-related queries
    elif any(word in query_lower for word in ["weather", "rain", "temperature", "climate"]):
        return """🌤️ **Weather Advisory:**

**Current Conditions:**
• Temperature: 28°C
• Humidity: 65%
• Wind: 12 km/h
• Rainfall: Light showers expected

**7-Day Forecast:** Moderate rain likely in next 3 days. Plan irrigation accordingly.

Visit the Weather Predictions page for detailed forecasts!"""
    
    # Crop advisory queries
    elif any(word in query_lower for word in ["sowing", "planting", "harvest", "crop"]):
        return """🌱 **Crop Advisory:**

**Current Season Recommendations:**
• **Kharif Season**: Rice, Cotton, Soybean
• **Rabi Season**: Wheat, Mustard, Chickpea

**Best Practices:**
✅ Use certified seeds
✅ Follow recommended spacing
✅ Apply balanced fertilizers
✅ Monitor for pests regularly

Which crop would you like specific guidance on?"""
    
    # Disease-related queries
    elif any(word in query_lower for word in ["disease", "pest", "infection", "problem"]):
        return """🔬 **Disease Detection & Management:**

Upload a photo of affected plant on our Disease Detection page for AI-powered diagnosis.

**Common Issues:**
• Leaf spots → Fungicide treatment
• Wilting → Check soil moisture
• Yellowing → Nutrient deficiency
• Pest damage → Integrated pest management

Would you like specific treatment recommendations?"""
    
    # Default response
    else:
        return f"""I'm here to help you with:

• 🌾 **Government Schemes** - Eligibility, benefits, application
• 💰 **Market Prices** - Real-time rates, forecasts, trends
• 🌤️ **Weather** - Predictions, advisories, alerts
• 🌱 **Crop Advisory** - Sowing, harvest, best practices
• 🔬 **Disease Detection** - AI-powered diagnosis

You asked: *"{query}"*

Could you please be more specific? For example:
- "What schemes are available for small farmers?"
- "What is the current wheat price?"
- "When should I sow cotton?"
"""