"""
AgriSaathi — Agriculture Management Platform with Genie AI + Sarvam AI Voice
Government schemes intelligence + Farm management for Indian farmers
"""
import streamlit as st
from home import show_home_page
from genie_client import GenieClient
import requests
import base64
import json

# ══════════════════════════════════════════════════════════════════════
# GENIE CONFIGURATION
# ══════════════════════════════════════════════════════════════════════

GENIE_SPACE_ID = "01f13b0afb75174f98cfb270ce30cb5b"

# Initialize Genie client and store in session state (only once)
if 'genie_client' not in st.session_state:
    try:
        st.session_state.genie_client = GenieClient(space_id=GENIE_SPACE_ID)
        print(f"✅ Genie client initialized with space ID: {GENIE_SPACE_ID}")
    except Exception as e:
        print(f"[app] Warning: Could not initialize Genie client: {e}")
        st.session_state.genie_client = None

# ══════════════════════════════════════════════════════════════════════
# SARVAM AI CONFIGURATION
# ══════════════════════════════════════════════════════════════════════

SARVAM_API_KEY = "sk_s9bltkwr_0ESJAVex8TCKAhUzSxVGhbf3"
SARVAM_STT_URL = "https://api.sarvam.ai/speech-to-text"
SARVAM_TTS_URL = "https://api.sarvam.ai/text-to-speech"
SARVAM_TRANSLATE_URL = "https://api.sarvam.ai/translate"

# Session state for voice
if 'voice_enabled' not in st.session_state:
    st.session_state.voice_enabled = False
if 'selected_language' not in st.session_state:
    st.session_state.selected_language = "en-IN"
if 'audio_response' not in st.session_state:
    st.session_state.audio_response = None
if 'tts_audio' not in st.session_state:
    st.session_state.tts_audio = None


def sarvam_speech_to_text(audio_bytes, language="hi-IN"):
    """
    Convert speech to text using Sarvam AI STT API.

    Args:
        audio_bytes: Raw audio bytes (WAV preferred)
        language: BCP-47 language code e.g. "hi-IN", "en-IN"

    Returns:
        Transcribed text string, or error message
    """
    try:
        headers = {
            "api-subscription-key": SARVAM_API_KEY,
        }

        # STT expects multipart/form-data
        files = {
            "file": ("audio.wav", audio_bytes, "audio/wav"),
        }
        data = {
            "language_code": language,
            "model": "saarika:v2",
            "with_timestamps": False,
        }

        response = requests.post(
            SARVAM_STT_URL, headers=headers,
            files=files, data=data, timeout=30
        )

        if response.status_code == 200:
            result = response.json()
            return result.get("transcript", "")
        else:
            return f"STT Error {response.status_code}: {response.text}"

    except Exception as e:
        return f"Speech-to-text error: {str(e)}"


def sarvam_text_to_speech(text, language="hi-IN", speaker="priya"):
    """
    Convert text to speech using Sarvam AI TTS API.

    Args:
        text    : Text to convert (max 2500 chars)
        language: BCP-47 language code e.g. "hi-IN", "en-IN"
        speaker : Voice name (priya, rahul, neha, rohan, etc.)
                  Valid speakers for bulbul:v3: aditya, ritu, ashutosh, priya, neha, 
                  rahul, pooja, rohan, simran, kavya, amit, dev, ishita, shreya, ratan, 
                  varun, manan, sumit, roopa, kabir, aayan, shubh, advait, anand, tanya, 
                  tarun, sunny, mani, gokul, vijay, shruti, suhani, mohit, kavitha, 
                  rehan, soham, rupali, niharika

    Returns:
        Raw audio bytes (WAV), or None on failure
    """
    try:
        headers = {
            "api-subscription-key": SARVAM_API_KEY,
            "Content-Type": "application/json",
        }

        payload = {
            "inputs": [text],
            "target_language_code": language,
            "speaker": speaker,
            "model": "bulbul:v3",
            "speech_sample_rate": 22050,
            "enable_preprocessing": True,
            "audio_format": "wav",
        }

        response = requests.post(
            SARVAM_TTS_URL, headers=headers,
            json=payload, timeout=30
        )

        if response.status_code == 200:
            result = response.json()
            audio_b64 = result.get("audios", [None])[0]
            if audio_b64:
                import base64
                return base64.b64decode(audio_b64)
            else:
                st.error("TTS Error: No audio in response")
                return None
        else:
            st.error(f"TTS Error {response.status_code}: {response.text}")
            return None

    except Exception as e:
        st.error(f"Text-to-speech error: {str(e)}")
        return None


def sarvam_translate(text, source_lang="en-IN", target_lang="hi-IN"):
    """
    Translate text using Sarvam AI Translation API.

    Args:
        text       : Text to translate
        source_lang: BCP-47 source language code e.g. "en-IN"
        target_lang: BCP-47 target language code e.g. "hi-IN"

    Returns:
        Translated text string, or original text on failure
    """
    try:
        headers = {
            "api-subscription-key": SARVAM_API_KEY,
            "Content-Type": "application/json",
        }

        payload = {
            "input": text,
            "source_language_code": source_lang,
            "target_language_code": target_lang,
            "model": "mayura:v1",
            "enable_preprocessing": False,
        }

        response = requests.post(
            SARVAM_TRANSLATE_URL, headers=headers,
            json=payload, timeout=30
        )

        if response.status_code == 200:
            result = response.json()
            return result.get("translated_text", text)
        else:
            st.warning(f"Translation Error {response.status_code}: {response.text}")
            return text

    except Exception as e:
        st.warning(f"Translation error: {str(e)}")
        return text

# Store voice functions in session state for access by other modules
st.session_state.sarvam_speech_to_text = sarvam_speech_to_text
st.session_state.sarvam_text_to_speech = sarvam_text_to_speech

# ══════════════════════════════════════════════════════════════════════
# GLOBAL DARK THEME CSS + VOICE ASSISTANT BUTTON
# ══════════════════════════════════════════════════════════════════════

st.markdown("""
    <style>
    /* Fixed viewport height */
    html, body, [data-testid="stAppViewContainer"] {
        height: 100vh !important;
        overflow: hidden !important;
    }
    
    [data-testid="stAppViewContainer"] {
        display: flex !important;
        flex-direction: row !important;
    }
    
    [data-testid="stAppViewContainer"] > .main {
        height: 100vh !important;
        overflow-y: auto !important;
        overflow-x: hidden !important;
        flex: 1 !important;
        width: 100% !important;
        max-width: 100% !important;
        padding: 0.5rem 3rem !important;
    }
    
    .block-container {
        padding-top: 1rem !important;
        padding-bottom: 2rem !important;
        max-width: 100% !important;
        padding-left: 2rem !important;
        padding-right: 2rem !important;
    }
    
    h1 {
        margin-top: 0 !important;
        margin-bottom: 1rem !important;
        padding-top: 0 !important;
    }
    
    /* Global Dark Theme */
    .main {
        background-color: #0e1117;
        color: #fafafa;
    }
    
    [data-testid="stSidebar"] {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%) !important;
        border-right: 2px solid #3b82f6 !important;
    }
    
    [data-testid="stSidebar"] * {
        color: #fafafa !important;
    }
    
    h1, h2, h3, h4, h5, h6 {
        color: #fafafa !important;
    }
    
    p, span, div {
        color: #e2e8f0 !important;
    }
    
    .stButton > button {
        background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 10px 24px;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 16px rgba(59, 130, 246, 0.3);
    }
    
    div[data-testid="stMetricValue"] {
        color: #60a5fa !important;
    }
    
    div[data-testid="stMetricLabel"] {
        color: #94a3b8 !important;
    }
    
    .dataframe {
        background-color: #1e2530 !important;
        color: #fafafa !important;
    }
    
    .dataframe th {
        background-color: #2d3748 !important;
        color: #fafafa !important;
    }
    
    .dataframe td {
        background-color: #1e2530 !important;
        color: #e2e8f0 !important;
    }
    
    .stSelectbox > div > div,
    .stMultiSelect > div > div,
    .stTextInput > div > div > input,
    .stTextArea > div > div > textarea {
        background-color: #1e2530 !important;
        color: #fafafa !important;
        border-color: #374151 !important;
    }
    
    .stTabs [data-baseweb="tab-list"] {
        background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%);
        border-radius: 12px;
        padding: 8px;
        margin-top: 0.5rem !important;
    }
    
    .stTabs [data-baseweb="tab"] {
        color: #cbd5e1;
        background-color: transparent;
        border-radius: 8px;
        padding: 12px 24px;
    }
    
    .stTabs [aria-selected="true"] {
        background-color: rgba(255, 255, 255, 0.15);
        color: #fafafa;
    }
    
    ::-webkit-scrollbar {
        width: 10px;
        height: 10px;
    }
    
    ::-webkit-scrollbar-track {
        background: #1e2530;
        border-radius: 5px;
    }
    
    ::-webkit-scrollbar-thumb {
        background: linear-gradient(180deg, #4a5568 0%, #2d3748 100%);
        border-radius: 5px;
        border: 2px solid #1e2530;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(180deg, #718096 0%, #4a5568 100%);
    }
    
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    
    hr {
        border-color: #374151 !important;
    }
    
    [data-testid="column"] {
        width: 100% !important;
        min-width: 0 !important;
    }
    
    /* Simple chatbot styling */
    .stChatMessage {
        background: rgba(30, 41, 59, 0.8) !important;
        border-radius: 12px !important;
        padding: 12px 16px !important;
        margin-bottom: 12px !important;
    }
    
    .stChatMessage[data-testid*="user"] {
        background: linear-gradient(135deg, rgba(59, 130, 246, 0.2) 0%, rgba(37, 99, 235, 0.3) 100%) !important;
        border-left: 3px solid #3b82f6 !important;
    }
    
    .stChatMessage[data-testid*="assistant"] {
        background: linear-gradient(135deg, rgba(139, 92, 246, 0.15) 0%, rgba(236, 72, 153, 0.15) 100%) !important;
        border-left: 3px solid #8b5cf6 !important;
    }
    
    /* ══════════════════════════════════════════════════════════════ */
    /* FLOATING VOICE ASSISTANT BUTTON (SARVAM AI)                     */
    /* ══════════════════════════════════════════════════════════════ */
    
    .voice-assistant-button {
        position: fixed !important;
        bottom: 30px !important;
        right: 30px !important;
        width: 70px !important;
        height: 70px !important;
        border-radius: 50% !important;
        background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%) !important;
        color: white !important;
        border: 3px solid #ea580c !important;
        box-shadow: 0 8px 24px rgba(245, 158, 11, 0.6) !important;
        cursor: pointer !important;
        z-index: 999999 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-size: 32px !important;
        transition: all 0.3s ease !important;
        animation: voice-pulse 2s infinite !important;
    }
    
    .voice-assistant-button:hover {
        transform: scale(1.15) !important;
        box-shadow: 0 12px 32px rgba(245, 158, 11, 0.9) !important;
    }
    
    .voice-assistant-button.recording {
        background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%) !important;
        border-color: #b91c1c !important;
        animation: voice-recording 0.8s infinite !important;
    }
    
    @keyframes voice-pulse {
        0%, 100% {
            box-shadow: 0 8px 24px rgba(245, 158, 11, 0.6);
        }
        50% {
            box-shadow: 0 12px 36px rgba(245, 158, 11, 1);
        }
    }
    
    @keyframes voice-recording {
        0%, 100% {
            transform: scale(1);
        }
        50% {
            transform: scale(1.1);
        }
    }
    
    /* Voice panel */
    .voice-panel {
        position: fixed !important;
        bottom: 120px !important;
        right: 30px !important;
        width: 350px !important;
        max-width: calc(100vw - 60px) !important;
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%) !important;
        border-radius: 16px !important;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.7) !important;
        border: 2px solid #f59e0b !important;
        padding: 20px !important;
        z-index: 999998 !important;
    }
    
    .voice-panel-header {
        color: #fbbf24 !important;
        font-size: 18px !important;
        font-weight: 700 !important;
        margin-bottom: 16px !important;
        display: flex !important;
        align-items: center !important;
        gap: 8px !important;
    }
    
    .voice-status {
        background: rgba(245, 158, 11, 0.1) !important;
        border: 1px solid #f59e0b !important;
        border-radius: 8px !important;
        padding: 12px !important;
        margin: 12px 0 !important;
        color: #fde68a !important;
        font-size: 14px !important;
    }
    
    .language-badge {
        display: inline-block !important;
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%) !important;
        color: white !important;
        padding: 4px 12px !important;
        border-radius: 12px !important;
        font-size: 12px !important;
        font-weight: 600 !important;
        margin-right: 8px !important;
    }
    
    /* Text-to-Speech box styling */
    .tts-box {
        background: rgba(245, 158, 11, 0.05) !important;
        border: 1px solid #f59e0b !important;
        border-radius: 12px !important;
        padding: 16px !important;
        margin: 16px 0 !important;
    }
    </style>
""", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════
# SESSION STATE
# ══════════════════════════════════════════════════════════════════════

if 'logged_in' not in st.session_state:
    st.session_state.logged_in = True
if 'username' not in st.session_state:
    st.session_state.username = "Guest"
if 'show_signup' not in st.session_state:
    st.session_state.show_signup = False

# Chatbot state
if "chat_messages" not in st.session_state:
    st.session_state.chat_messages = [
        {"role": "assistant", "content": "👋 Hello! I'm your AgriSaathi AI assistant powered by Genie AI. Ask me about diseases, schemes, or agricultural data! 🎤 Use voice for Hindi/English speech."}
    ]

# Voice state
if 'voice_recording' not in st.session_state:
    st.session_state.voice_recording = False
if 'voice_transcript' not in st.session_state:
    st.session_state.voice_transcript = ""

# ══════════════════════════════════════════════════════════════════════
# FLOATING VOICE ASSISTANT (VISIBLE ON ALL PAGES)
# ══════════════════════════════════════════════════════════════════════

# Create sidebar for voice settings
with st.sidebar:
    st.markdown("### 🎤 Sarvam AI Voice Assistant")
    st.caption("Speak in Hindi or English")
    
    # Language selection
    voice_lang = st.selectbox(
        "🌐 Voice Language",
        options=[
            ("हिंदी (Hindi)", "hi-IN"),
            ("English (India)", "en-IN")
        ],
        format_func=lambda x: x[0],
        key="voice_language_selector"
    )
    st.session_state.selected_language = voice_lang[1]
    
    # Voice output toggle - FIXED: Don't assign when using key
    st.checkbox("🔊 Enable Voice Response", value=True, key="enable_tts")
    
    st.markdown("---")
    
    # ══════════════════════════════════════════════════════════════════
    # TEXT-TO-SPEECH BOX
    # ══════════════════════════════════════════════════════════════════
    
    st.markdown("### 📝 Text to Speech")
    st.caption("Type text and convert to speech")
    
    tts_text = st.text_area(
        "Enter text:",
        placeholder="Type your message in Hindi or English...",
        height=100,
        key="tts_text_input",
        help="Enter text to convert to speech"
    )
    
    col_tts1, col_tts2 = st.columns(2)
    
    with col_tts1:
        # Language-aware voice selection with VALID bulbul:v3 speakers
        if st.session_state.selected_language == "hi-IN":
            voice_options = [
                ("👩 प्रिया (Priya)", "priya"),
                ("👨 राहुल (Rahul)", "rahul"),
                ("👩 नेहा (Neha)", "neha"),
                ("👨 रोहन (Rohan)", "rohan")
            ]
        else:
            voice_options = [
                ("👩 Priya", "priya"),
                ("👨 Rahul", "rahul"),
                ("👩 Neha", "neha"),
                ("👨 Rohan", "rohan")
            ]
        
        tts_speaker = st.selectbox(
            "🎭 Voice",
            options=voice_options,
            format_func=lambda x: x[0],
            key="tts_speaker_select",
            help="Select voice model (compatible with bulbul:v3)"
        )
    
    with col_tts2:
        if st.button("🔊 Convert", use_container_width=True, key="convert_tts_btn"):
            if tts_text and len(tts_text.strip()) > 0:
                with st.spinner("🎵 Generating..."):
                    audio_bytes = sarvam_text_to_speech(
                        tts_text,
                        st.session_state.selected_language,
                        speaker=tts_speaker[1]
                    )
                    
                    if audio_bytes:
                        st.session_state.tts_audio = audio_bytes
                        st.success("✅ Audio ready!")
                    else:
                        st.error("❌ Failed")
            else:
                st.warning("⚠️ Enter text first")
    
    # Display generated audio
    if st.session_state.tts_audio:
        st.markdown("**🎧 Generated Audio:**")
        try:
            st.audio(st.session_state.tts_audio, format='audio/wav')
        except Exception as e:
            st.error(f"Error: {str(e)}")
        
        # Clear audio button
        if st.button("🗑️ Clear", use_container_width=True, key="clear_tts_audio"):
            st.session_state.tts_audio = None
            st.rerun()
    
    st.markdown("---")
    st.markdown("**📌 How to use:**")
    st.markdown("1. **Text → Speech**: Type text, select voice, convert")
    st.markdown("2. **Chat**: Use Genie AI Chat tab for conversation")
    
    st.markdown("---")
    st.info("🇮🇳 **Powered by Sarvam AI** - Indian language AI")

# Voice button indicator (shown on all pages)
st.markdown("""
    <div style="position: fixed; bottom: 110px; right: 30px; z-index: 999999; 
                background: rgba(15, 23, 42, 0.9); padding: 8px 16px; 
                border-radius: 20px; border: 1px solid #f59e0b;
                font-size: 12px; color: #fbbf24; font-weight: 600;">
        🎤 Voice Assistant (Sarvam AI)
    </div>
""", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════
# MAIN CONTENT
# ══════════════════════════════════════════════════════════════════════

show_home_page()
