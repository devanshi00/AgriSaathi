import streamlit as st
import streamlit.components.v1 as components

def show_schemes_summary():
    """
    Schemes Portal
    """
    
    # Dashboard configuration
    DASHBOARD_ID = "01f13ab302f31b8db4abd7917fbaf704"
    WORKSPACE_URL = "https://dbc-3c87006a-64af.cloud.databricks.com"
    WORKSPACE_ID = "7474654478800280"
    
    # Embed URL with DARK THEME parameter
    embed_url = f"{WORKSPACE_URL}/embed/dashboardsv3/{DASHBOARD_ID}?o={WORKSPACE_ID}&theme=dark"
    
    # Dark theme CSS for the page wrapper
    st.markdown("""
    <style>
    /* Dark background for entire page */
    .main {
        background-color: #0f1419;
    }
    
    /* Dark themed iframe container */
    .element-container iframe {
        border: 2px solid #1e3a8a;
        border-radius: 12px;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.6);
        background-color: #1a1a1a;
    }
    
    /* Header styling */
    .dashboard-header {
        background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%);
        padding: 24px 32px;
        border-radius: 12px;
        text-align: center;
        margin-bottom: 24px;
        box-shadow: 0 4px 12px rgba(30, 58, 138, 0.5);
        border: 1px solid #2563eb;
    }
    
    .dashboard-title {
        color: #ffffff;
        font-size: 2em;
        font-weight: 700;
        margin: 0;
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
    }
    
    .dashboard-subtitle {
        color: #cbd5e1;
        font-size: 1.1em;
        margin-top: 8px;
        font-weight: 400;
    }
    
    /* Footer styling */
    .dashboard-footer {
        background: linear-gradient(135deg, #1e2530 0%, #2d3748 100%);
        padding: 16px;
        border-radius: 8px;
        text-align: center;
        margin-top: 20px;
        border: 1px solid #374151;
    }
    
    .dashboard-footer p {
        color: #94a3b8;
        font-size: 0.9em;
        margin: 0;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Dark themed header
    st.markdown("""
    <div class="dashboard-header">
        <h1 class="dashboard-title">🌱 Schemes Portal</h1>
        <p class="dashboard-subtitle">Retail Revenue & Supply Chain Analytics Dashboard</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Embed the dashboard with DARK THEME
    components.iframe(
        src=embed_url,
        height=1400,
        scrolling=True
    )
    
    # # Dark themed footer
    # st.markdown("""
    # <div class="dashboard-footer">
    #     <p>📊 Dashboard ID: 01f13ab302f31b8db4abd7917fbaf704 | Powered by Databricks</p>
    # </div>
    # """, unsafe_allow_html=True)
