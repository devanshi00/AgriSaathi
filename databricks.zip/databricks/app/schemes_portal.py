import streamlit as st

# Scheme data with benefit types and eligibility
LOCAL_SCHEMES = [
    {
        "name": "PM-KISAN",
        "full_name": "Pradhan Mantri Kisan Samman Nidhi",
        "amount": "₹6,000/year",
        "description": "Direct income support to small & marginal farmers",
        "category": "Income Support",
        "priority": "high",
        "tags": ["Direct Transfer", "Farmers", "Income"],
        "benefit_type": "Cash",
        "eligible_states": ["All India"],
        "eligible_castes": ["All Categories"],
        "url": "https://pmkisan.gov.in/"
    },
    {
        "name": "Soil Health Card",
        "full_name": "Soil Health Card Scheme",
        "amount": "Free Testing",
        "description": "Free soil testing and crop-specific recommendations",
        "category": "Crop Health",
        "priority": "medium",
        "tags": ["Testing", "Soil", "Advisory"],
        "benefit_type": "In-kind",
        "eligible_states": ["All India"],
        "eligible_castes": ["All Categories"],
        "url": "https://soilhealth.dac.gov.in/"
    },
    {
        "name": "PMFBY",
        "full_name": "Pradhan Mantri Fasal Bima Yojana",
        "amount": "Up to 2% Premium",
        "description": "Crop insurance against natural calamities",
        "category": "Insurance",
        "priority": "high",
        "tags": ["Insurance", "Risk", "Protection"],
        "benefit_type": "Composite",
        "eligible_states": ["All India"],
        "eligible_castes": ["All Categories"],
        "url": "https://pmfby.gov.in/"
    },
    {
        "name": "KCC",
        "full_name": "Kisan Credit Card",
        "amount": "Up to ₹3 Lakhs",
        "description": "Short-term credit for agricultural needs at 4% interest",
        "category": "Credit",
        "priority": "high",
        "tags": ["Credit", "Loan", "Finance"],
        "benefit_type": "Cash",
        "eligible_states": ["All India"],
        "eligible_castes": ["All Categories"],
        "url": "https://www.india.gov.in/spotlight/kisan-credit-card"
    },
    {
        "name": "PM-Maandhan",
        "full_name": "PM Kisan Maandhan Yojana",
        "amount": "₹3,000/month",
        "description": "Pension scheme for small & marginal farmers (60+ age)",
        "category": "Social Security",
        "priority": "medium",
        "tags": ["Pension", "Elderly", "Security"],
        "benefit_type": "Cash",
        "eligible_states": ["All India"],
        "eligible_castes": ["All Categories"],
        "url": "https://maandhan.in/"
    },
    {
        "name": "e-NAM",
        "full_name": "National Agriculture Market",
        "amount": "Free Access",
        "description": "Online trading platform for agricultural commodities",
        "category": "Market Access",
        "priority": "medium",
        "tags": ["Trading", "Market", "Digital"],
        "benefit_type": "In-kind",
        "eligible_states": ["All India"],
        "eligible_castes": ["All Categories"],
        "url": "https://enam.gov.in/"
    },
    {
        "name": "PMKSY",
        "full_name": "Pradhan Mantri Krishi Sinchayee Yojana",
        "amount": "Subsidy Support",
        "description": "Irrigation support and water conservation measures",
        "category": "Irrigation",
        "priority": "high",
        "tags": ["Irrigation", "Water", "Infrastructure"],
        "benefit_type": "Composite",
        "eligible_states": ["All India"],
        "eligible_castes": ["All Categories"],
        "url": "https://pmksy.gov.in/"
    },
    {
        "name": "SC/ST Farmer Support",
        "full_name": "Special Component Plan for SC/ST Farmers",
        "amount": "₹10,000/year",
        "description": "Additional financial assistance for SC/ST farmers",
        "category": "Income Support",
        "priority": "high",
        "tags": ["Direct Transfer", "SC/ST", "Support"],
        "benefit_type": "Cash",
        "eligible_states": ["All India"],
        "eligible_castes": ["SC", "ST"],
        "url": "https://tribal.nic.in/"
    },
    {
        "name": "OBC Agri Loan",
        "full_name": "OBC Agricultural Loan Scheme",
        "amount": "Up to ₹5 Lakhs",
        "description": "Subsidized loans for OBC farmers at 3% interest",
        "category": "Credit",
        "priority": "medium",
        "tags": ["Credit", "Loan", "OBC"],
        "benefit_type": "Cash",
        "eligible_states": ["All India"],
        "eligible_castes": ["OBC"],
        "url": "https://www.india.gov.in/"
    }
]

GLOBAL_SCHEMES = [
    {
        "name": "World Bank Climate-Smart Agriculture",
        "full_name": "Climate-Smart Agriculture Support",
        "amount": "$500M Fund",
        "description": "Support for climate-resilient farming practices",
        "category": "Climate Action",
        "priority": "high",
        "tags": ["Climate", "Sustainability", "Global"],
        "benefit_type": "Composite",
        "eligible_states": ["All India"],
        "eligible_castes": ["All Categories"],
        "url": "https://www.worldbank.org/"
    },
    {
        "name": "FAO Digital Agriculture",
        "full_name": "FAO Digital Agriculture Initiative",
        "amount": "Tech Support",
        "description": "Digital tools and capacity building for farmers",
        "category": "Technology",
        "priority": "medium",
        "tags": ["Digital", "Technology", "Training"],
        "benefit_type": "In-kind",
        "eligible_states": ["All India"],
        "eligible_castes": ["All Categories"],
        "url": "https://www.fao.org/"
    },
    {
        "name": "CGIAR Research Partnership",
        "full_name": "CGIAR Agricultural Research",
        "amount": "Research Access",
        "description": "Access to improved crop varieties and research",
        "category": "Research",
        "priority": "medium",
        "tags": ["Research", "Seeds", "Innovation"],
        "benefit_type": "In-kind",
        "eligible_states": ["All India"],
        "eligible_castes": ["All Categories"],
        "url": "https://www.cgiar.org/"
    },
    {
        "name": "IFAD Rural Finance",
        "full_name": "IFAD Rural Finance Programme",
        "amount": "Grant Support",
        "description": "Financial inclusion and rural development support",
        "category": "Finance",
        "priority": "high",
        "tags": ["Finance", "Rural", "Development"],
        "benefit_type": "Cash",
        "eligible_states": ["All India"],
        "eligible_castes": ["All Categories"],
        "url": "https://www.ifad.org/"
    }
]

INDIAN_STATES = [
    "All India", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
    "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka",
    "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram",
    "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu",
    "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
    "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu",
    "Delhi", "Jammu and Kashmir", "Ladakh", "Lakshadweep", "Puducherry"
]

CASTE_CATEGORIES = ["All Categories", "General", "OBC", "SC", "ST", "EWS"]
BENEFIT_TYPES = ["All Types", "Cash", "In-kind", "Composite"]

def apply_schemes_css():
    st.markdown("""
        <style>
        /* Dropdown styling */
        .stSelectbox > div > div,
        .stMultiSelect > div > div {
            background-color: #1e2530;
            color: #fafafa;
            border-color: #374151;
        }
        
        [data-baseweb="select"] ul,
        [data-baseweb="select"] li {
            background-color: #1e2530;
            color: #fafafa;
        }
        
        [data-baseweb="select"] li:hover {
            background-color: #2d3748;
        }
        
        /* Search input styling */
        .stTextInput > div > div > input {
            background-color: #1e2530;
            color: #fafafa;
            border-color: #374151;
        }
        
        .stTextInput > div > div > input:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 1px #3b82f6;
        }
        
        /* Tab styling */
        .stTabs [data-baseweb="tab-list"] {
            gap: 8px;
            background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%);
            padding: 8px;
            border-radius: 12px;
        }
        
        .stTabs [data-baseweb="tab"] {
            height: 50px;
            background-color: transparent;
            border-radius: 8px;
            color: #cbd5e1;
            font-weight: 500;
            padding: 0 24px;
        }
        
        .stTabs [aria-selected="true"] {
            background-color: rgba(255, 255, 255, 0.15);
            color: #fafafa;
            font-weight: 600;
        }
        
        /* Scheme card styling */
        .scheme-card {
            background: linear-gradient(135deg, #1e2530 0%, #2d3748 100%);
            border: 1px solid #374151;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .scheme-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 24px rgba(59, 130, 246, 0.15);
            border-color: #3b82f6;
        }
        
        .scheme-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 16px;
        }
        
        .scheme-title {
            font-size: 22px;
            font-weight: 700;
            color: #fafafa;
            margin-bottom: 4px;
        }
        
        .scheme-subtitle {
            font-size: 13px;
            color: #94a3b8;
            margin-bottom: 8px;
        }
        
        .scheme-amount {
            font-size: 24px;
            font-weight: 700;
            color: #22c55e;
            text-align: right;
        }
        
        .scheme-description {
            color: #cbd5e1;
            line-height: 1.6;
            margin-bottom: 16px;
            font-size: 15px;
        }
        
        .scheme-meta {
            display: flex;
            gap: 12px;
            margin-bottom: 16px;
            flex-wrap: wrap;
        }
        
        .scheme-tags {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        
        .scheme-tag {
            background: rgba(59, 130, 246, 0.2);
            color: #60a5fa;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            border: 1px solid rgba(59, 130, 246, 0.3);
        }
        
        .priority-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .priority-high {
            background: rgba(239, 68, 68, 0.2);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }
        
        .priority-medium {
            background: rgba(245, 158, 11, 0.2);
            color: #fbbf24;
            border: 1px solid rgba(245, 158, 11, 0.3);
        }
        
        .priority-low {
            background: rgba(34, 197, 94, 0.2);
            color: #4ade80;
            border: 1px solid rgba(34, 197, 94, 0.3);
        }
        
        .benefit-type-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            background: rgba(168, 85, 247, 0.2);
            color: #c084fc;
            border: 1px solid rgba(168, 85, 247, 0.3);
        }
        
        /* Apply button styling */
        .apply-button {
            display: inline-block;
            width: 100%;
            padding: 14px 28px;
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
            color: white;
            text-align: center;
            border-radius: 12px;
            font-weight: 600;
            font-size: 16px;
            text-decoration: none;
            transition: all 0.3s ease;
            border: 2px solid transparent;
            cursor: pointer;
            margin-top: 8px;
        }
        
        .apply-button:hover {
            background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(34, 197, 94, 0.3);
            border-color: #22c55e;
        }
        
        /* Success message styling */
        .success-message {
            background: linear-gradient(135deg, #064e3b 0%, #065f46 100%);
            border: 2px solid #10b981;
            border-radius: 12px;
            padding: 16px;
            color: #d1fae5;
            margin: 16px 0;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .filter-section {
            background: linear-gradient(135deg, #1e2530 0%, #2d3748 100%);
            border: 1px solid #374151;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 24px;
        }
        </style>
    """, unsafe_allow_html=True)

def render_scheme_card(scheme):
    """Render a scheme card with Apply button"""
    priority_class = f"priority-{scheme['priority']}"
    
    card_html = f"""
    <div class="scheme-card">
        <div class="scheme-header">
            <div>
                <div class="scheme-title">{scheme['name']}</div>
                <div class="scheme-subtitle">{scheme['full_name']}</div>
            </div>
            <div class="scheme-amount">{scheme['amount']}</div>
        </div>
        
        <div class="scheme-description">
            {scheme['description']}
        </div>
        
        <div class="scheme-meta">
            <span class="priority-badge {priority_class}">
                {scheme['priority']} Priority
            </span>
            <span class="benefit-type-badge">
                {scheme['benefit_type']}
            </span>
        </div>
        
        <div class="scheme-tags">
            {''.join([f'<span class="scheme-tag">{tag}</span>' for tag in scheme['tags']])}
        </div>
    </div>
    """
    
    st.markdown(card_html, unsafe_allow_html=True)
    
    # Apply button with unique key
    scheme_key = scheme['name'].replace(" ", "_").replace("/", "_").lower()
    if st.button(f"🚀 Apply Now", key=f"apply_{scheme_key}", use_container_width=True):
        st.success(f"✅ Redirecting to {scheme['name']}... Please visit: {scheme['url']}")
        st.markdown(f"""
        <div class="success-message">
            <strong>🎉 Application Initiated!</strong><br>
            You will be redirected to <strong>{scheme['name']}</strong> portal.<br>
            <a href="{scheme['url']}" target="_blank" style="color: #6ee7b7; text-decoration: underline;">
                Click here to visit {scheme['url']}
            </a>
        </div>
        """, unsafe_allow_html=True)

def filter_schemes(schemes, state, caste, benefit_type, search_query):
    """Filter schemes based on selected criteria"""
    filtered = schemes
    
    # Filter by state
    if state != "All India":
        filtered = [s for s in filtered if state in s['eligible_states'] or "All India" in s['eligible_states']]
    
    # Filter by caste
    if caste != "All Categories":
        filtered = [s for s in filtered if caste in s['eligible_castes'] or "All Categories" in s['eligible_castes']]
    
    # Filter by benefit type
    if benefit_type != "All Types":
        filtered = [s for s in filtered if s['benefit_type'] == benefit_type]
    
    # Filter by search query
    if search_query:
        search_lower = search_query.lower()
        filtered = [s for s in filtered if 
                   search_lower in s['name'].lower() or
                   search_lower in s['full_name'].lower() or
                   search_lower in s['description'].lower() or
                   any(search_lower in tag.lower() for tag in s['tags'])]
    
    return filtered

def show_schemes_portal():
    apply_schemes_css()
    
    st.title("🌾 Government Schemes Portal")
    st.markdown("### Discover and apply for agricultural schemes")
    
    # Filter section
    st.markdown('<div class="filter-section">', unsafe_allow_html=True)
    
    # Dropdowns in 3 columns
    col1, col2, col3 = st.columns(3)
    
    with col1:
        selected_state = st.selectbox(
            "📍 Select State/Location",
            options=INDIAN_STATES,
            index=0
        )
    
    with col2:
        selected_caste = st.selectbox(
            "👥 Select Category",
            options=CASTE_CATEGORIES,
            index=0
        )
    
    with col3:
        selected_benefit_type = st.selectbox(
            "💰 Benefit Type",
            options=BENEFIT_TYPES,
            index=0
        )
    
    # Search bar
    search_query = st.text_input(
        "🔍 Search schemes by name, description, or tags",
        placeholder="e.g., PM-KISAN, insurance, credit..."
    )
    
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Tabs for Local and Global schemes
    tab1, tab2 = st.tabs(["🇮🇳 Local Schemes", "🌍 Global Schemes"])
    
    with tab1:
        filtered_local = filter_schemes(LOCAL_SCHEMES, selected_state, selected_caste, selected_benefit_type, search_query)
        
        if filtered_local:
            st.markdown(f"**Showing {len(filtered_local)} scheme(s)**")
            for scheme in filtered_local:
                render_scheme_card(scheme)
        else:
            st.info("No schemes match your filter criteria. Try adjusting the filters.")
    
    with tab2:
        filtered_global = filter_schemes(GLOBAL_SCHEMES, selected_state, selected_caste, selected_benefit_type, search_query)
        
        if filtered_global:
            st.markdown(f"**Showing {len(filtered_global)} scheme(s)**")
            for scheme in filtered_global:
                render_scheme_card(scheme)
        else:
            st.info("No schemes match your filter criteria. Try adjusting the filters.")

if __name__ == "__main__":
    show_schemes_portal()
