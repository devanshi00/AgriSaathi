import time
import json
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import re
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

BASE = "https://www.myscheme.gov.in"
CATEGORY_URL = (
    "https://www.myscheme.gov.in/search/category/Agriculture,Rural%20&%20Environment"
)
TOTAL_PAGES = 84
OUTPUT_FILE = "myscheme_agriculture_schemes.json"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    )
}


def get_driver(headless=True):
    options = Options()
    if headless:
        options.add_argument("--headless=new")
    options.add_argument("--window-size=1600,2200")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    return webdriver.Chrome(options=options)


def extract_scheme_cards(html):
    soup = BeautifulSoup(html, "html.parser")
    schemes = []
    seen = set()

    title_links = soup.select('h2[id^="scheme-name-"] a[href^="/schemes/"]')

    for a in title_links:
        href = a.get("href", "").strip()
        full_url = urljoin(BASE, href)
        title = a.get_text(" ", strip=True)

        if not href or full_url in seen:
            continue
        seen.add(full_url)

        card = a
        for _ in range(8):
            card = card.parent
            if card is None:
                break
            classes = card.get("class", [])
            if card.name == "div" and (
                card.get("role") == "article" or "shadow-md" in classes
            ):
                break

        state = None
        brief = None
        tags = []

        if card:
            state_el = card.select_one('h2[aria-label^="Filter by"]')
            if state_el:
                state = state_el.get_text(" ", strip=True)

            brief_el = card.select_one('span[aria-label^="Brief description:"]')
            if brief_el:
                brief = brief_el.get_text(" ", strip=True)

            tag_els = card.select('div[aria-label^="Filter by tag:"]')
            tags = [tag.get_text(" ", strip=True) for tag in tag_els]
        # Add this line before schemes.append(...)
        scheme_type = (
            "Central"
            if state and re.search(
                r"\bministry\b|\bdepartment\b|\bcommission\b|\bcouncil\b|\bboard\b",
                state,
                re.IGNORECASE,
            )
            else "State"
        )

        schemes.append(
            {
                "title": title,
                "url": full_url,
                "state": state,
                "scheme_type": scheme_type,  # <-- new field
                "brief": brief,
                "tags": tags,
            }
        )

    return schemes


def get_first_card_title(driver):
    try:
        el = driver.find_element(By.CSS_SELECTOR, 'div[role="article"] a')
        return el.text.strip()
    except:
        return None


# def click_next_page(driver, wait):
#     """Click the right-arrow chevron in the pagination bar."""
#     try:
#         # Try clicking the parent <li> or wrapper of the next arrow instead of the SVG
#         pagination_svgs = driver.find_elements(By.CSS_SELECTOR, "ul svg")
#         next_svg = pagination_svgs[-1]

#         # Try clicking the parent element (usually a div or span wrapping the SVG)
#         parent = next_svg.find_element(By.XPATH, "..")
#         driver.execute_script("arguments[0].scrollIntoView(true);", parent)
#         time.sleep(0.3)

#         try:
#             parent.click()  # normal click on parent
#         except:
#             driver.execute_script("arguments[0].click();", parent)


#         return True
#     except Exception as e:
#         print(f"  Could not click next: {e}")
#         return False
def get_current_page_number(driver):
    """Find which page is currently active (has green background)."""
    try:
        # Active page li has bg-green-700 class
        active = driver.find_element(By.CSS_SELECTOR, "ul li.bg-green-700")
        return int(active.text.strip())
    except:
        return None


def click_next_page(driver, wait):
    """Click the next page li by finding current page + 1."""
    try:
        current = get_current_page_number(driver)
        if current is None:
            raise ValueError("Could not determine current page")

        next_page_num = current + 1
        print(f"  Clicking page {next_page_num}...")

        # Find all li elements in pagination and click the one with next number
        lis = driver.find_elements(By.CSS_SELECTOR, "ul li")
        for li in lis:
            if li.text.strip() == str(next_page_num):
                driver.execute_script("arguments[0].scrollIntoView(true);", li)
                time.sleep(0.3)
                li.click()
                return True

        raise ValueError(f"Could not find li for page {next_page_num}")

    except Exception as e:
        print(f"  Could not click next: {e}")
        return False


def wait_for_page_change(driver, old_title, timeout=15):
    """Wait until the first card title changes — confirms new page loaded."""
    end = time.time() + timeout
    while time.time() < end:
        try:
            el = driver.find_element(By.CSS_SELECTOR, 'div[role="article"] a')
            if el.text.strip() and el.text.strip() != old_title:
                return True
        except:
            pass
        time.sleep(0.5)
    return False


NOISE_PATTERNS = [
    r"Agriculture,Rural & Environment.*?(?=\n[A-Z]|\Z)",
    r"Are you sure you want to sign out\?.*?Sign Out",
    r"Filter By.*?Reset Filters\nClose",
    r"Back\nFilter By.*?Student\n1",
    r"For an exact match.*?\"Scheme Name\"\.",
    r"All Schemes\nState/UT Schemes\nCentral Schemes",
    r"Sort\nFilter\nWe found\n\d+\nschemes based on your preferences",
    r"Sort\nRelevance\nScheme Name \(A->Z\)\nScheme Name \(Z->A\)\nSort :.*?Scheme Name \(Z->A\)",
    r"English\nEnglish\nTheme",
    r"\|\s*\|",
    r"\d+\n\d+\n\d+.*?84",
    r"©️\n\d{4}\nGovernment of India.*",
]

BAD_PHRASES = [
    "Something went wrong",
    "Please try again later",
    "Sign In",
    "Cancel",
    "Ok",
    "You're being redirected",
    "Your mobile number will be shared",
    "You have already submitted an application",
    "You need to sign in before applying",
    "It seems you have already initiated",
    "Check Eligibility",
    "Apply Now",
    "Was this helpful?",
    "News and Updates",
    "No new news",
    "Share",
    "Accessibility",
    "Quick Links",
    "Powered by",
    "Digital India Corporation",
    "Ministry of Electronics",
]


def clean_full_text(text: str) -> str:
    for pattern in NOISE_PATTERNS:
        text = re.sub(pattern, "", text, flags=re.DOTALL)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def clean_scheme_text(text: str) -> str:
    lines = text.split("\n")
    cleaned = [
        l.strip() for l in lines if not any(b.lower() in l.lower() for b in BAD_PHRASES)
    ]
    return "\n".join(cleaned)


def get_scheme_text_requests(url):
    r = requests.get(url, headers=HEADERS, timeout=30)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    lines = [
        l.strip() for l in soup.get_text("\n", strip=True).splitlines() if l.strip()
    ]
    return "\n".join(lines)


def get_scheme_text_selenium(driver, url):
    driver.get(url)
    time.sleep(3)
    soup = BeautifulSoup(driver.page_source, "html.parser")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    lines = [
        l.strip() for l in soup.get_text("\n", strip=True).splitlines() if l.strip()
    ]
    return "\n".join(lines)


def load_existing(filepath):
    """Load already-scraped URLs so we can resume."""
    saved = {}
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            for item in json.load(f):
                saved[item["url"]] = item
        print(f"Resuming — {len(saved)} schemes already saved.")
    except (FileNotFoundError, json.JSONDecodeError):
        pass
    return saved


def get_scheme_text_requests(url):
    r = requests.get(url, headers=HEADERS, timeout=30)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    lines = [
        l.strip() for l in soup.get_text("\n", strip=True).splitlines() if l.strip()
    ]
    return "\n".join(lines)


def scrape_all_schemes():
    saved = load_existing(OUTPUT_FILE)
    all_results = dict(saved)

    driver = get_driver(headless=True)
    wait = WebDriverWait(driver, 15)

    try:
        print(f"Opening: {CATEGORY_URL}")
        driver.get(CATEGORY_URL)
        time.sleep(5)

        for page_num in range(1, TOTAL_PAGES + 1):
            print(f"\n{'=' * 60}")
            print(f"PAGE {page_num}/{TOTAL_PAGES}")
            print(f"{'=' * 60}")

            try:
                wait.until(
                    EC.presence_of_element_located(
                        (By.CSS_SELECTOR, 'div[role="article"]')
                    )
                )
            except Exception as e:
                print(f"  Timeout on page {page_num}: {e}")
                break

            schemes = extract_scheme_cards(driver.page_source)
            print(f"  Found {len(schemes)} cards on this page")

            for i, scheme in enumerate(schemes, 1):
                url = scheme["url"]

                if url in all_results and "full_text" in all_results[url]:
                    print(f"  [{i}/{len(schemes)}] Skipping: {scheme['title']}")
                    continue

                print(f"  [{i}/{len(schemes)}] {scheme['title']}")

                # ONLY use requests — never navigate the driver away from category page
                try:
                    text = get_scheme_text_requests(url)
                    text = clean_scheme_text(text)
                    if len(text) < 300 or "Something went wrong" in text:
                        raise ValueError("Incomplete page")
                except Exception as e:
                    print(f"    requests failed ({e}), storing brief only.")
                    text = scheme.get("brief", "") or "ERROR: Could not fetch"

                all_results[url] = {**scheme, "full_text": clean_full_text(text)}

            # Save after every page
            with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
                json.dump(list(all_results.values()), f, ensure_ascii=False, indent=2)
            print(f"  Saved {len(all_results)} total schemes so far.")

            if page_num == TOTAL_PAGES:
                break

            # Navigate to next page
            old_title = get_first_card_title(driver)
            clicked = click_next_page(driver, wait)
            if not clicked:
                print("  Failed to click next. Stopping.")
                break

            changed = wait_for_page_change(driver, old_title)
            if not changed:
                print(f"  Page did not change after page {page_num}. Stopping.")
                break

    finally:
        driver.quit()

    return list(all_results.values())


if __name__ == "__main__":
    data = scrape_all_schemes()
    print(f"\nDone. Total schemes: {len(data)}")
    print(f"Saved to {OUTPUT_FILE}")