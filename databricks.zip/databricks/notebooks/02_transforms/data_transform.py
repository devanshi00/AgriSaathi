# Databricks notebook source
# MAGIC %md
# MAGIC # 02 — Bronze → Silver (Spark Transforms)
# MAGIC Deduplicates, normalises crop names, filters to target mandis,
# MAGIC and writes clean records to the Silver Delta table.

# COMMAND ----------

import sys
sys.path.insert(0, "/Workspace/Repos/cse220001027@iiti.ac.in/AgriBuddy_hackathon/AgriBuddy/AgriBuddy/src")

from croppulse.config import BRONZE_TABLE, SILVER_TABLE, CROP_NAME_MAP, CROPS, MANDIS
from pyspark.sql import functions as F
from pyspark.sql.types import DateType

# COMMAND ----------

# MAGIC %md ## Step 1 — Read Bronze

# COMMAND ----------

bronze_df = spark.read.table(BRONZE_TABLE)
print(f"Bronze rows: {bronze_df.count():,}")
display(bronze_df.limit(5))

# COMMAND ----------

# Check actual values in Bronze table
bronze_df = spark.read.table(BRONZE_TABLE)
print("=== Sample rows ===")
display(bronze_df.limit(5))

print("\n=== Unique date formats ===")
display(bronze_df.select("date").distinct().limit(5))

print("\n=== Unique crop values ===")
display(bronze_df.select("crop").distinct())

print("\n=== Unique mandi values ===")
display(bronze_df.select("mandi").distinct())

# COMMAND ----------

# MAGIC %md ## Step 2 — Normalise crop names

# COMMAND ----------

# Build a Spark map expression to normalise Hindi/regional aliases
crop_map_expr = F.create_map(
    *[item for pair in CROP_NAME_MAP.items() for item in (F.lit(pair[0]), F.lit(pair[1]))]
)

silver_df = (
    bronze_df
    # Normalise crop name: lower → lookup → fallback to title-case original
    .withColumn(
        "crop",
        F.coalesce(
            crop_map_expr[F.lower(F.col("crop"))],
            F.initcap(F.col("crop"))
        )
    )
    # Cast date string → DateType
    .withColumn("date", F.to_date(F.col("date"), "yyyy-MM-dd").cast(DateType()))
    # Drop nulls on key columns
    .dropna(subset=["date", "crop", "mandi", "modal_price"])
    # Filter to target crops & mandis only
    .filter(F.col("crop").isin(CROPS) & F.col("mandi").isin(MANDIS))
    # Drop negative prices
    .filter(F.col("modal_price") > 0)
)

print(f"Silver rows after cleaning: {silver_df.count():,}")

# COMMAND ----------

# MAGIC %md ## Step 3 — Deduplicate (keep last record per date/crop/mandi)

# COMMAND ----------

from pyspark.sql.window import Window

dedup_window = Window.partitionBy("date", "crop", "mandi").orderBy(F.desc("modal_price"))

silver_df = (
    silver_df
    .withColumn("_rank", F.row_number().over(dedup_window))
    .filter(F.col("_rank") == 1)
    .drop("_rank")
)

print(f"Rows after dedup: {silver_df.count():,}")

# COMMAND ----------

# MAGIC %md ## Step 4 — Write to Silver Delta

# COMMAND ----------

(
    silver_df
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .partitionBy("crop", "mandi")
    .saveAsTable(SILVER_TABLE)
)

print(f"Silver table written: {SILVER_TABLE}")

# COMMAND ----------

# MAGIC %md ## Step 5 — Verify

# COMMAND ----------

result = spark.read.table(SILVER_TABLE)
display(result.groupBy("crop", "mandi").agg(
    F.count("*").alias("rows"),
    F.min("date").alias("from_date"),
    F.max("date").alias("to_date"),
    F.avg("modal_price").alias("avg_price"),
).orderBy("crop", "mandi"))

# COMMAND ----------

import sys
sys.path.insert(0, "/Workspace/Repos/cse220001027@iiti.ac.in/AgriBuddy_hackathon/AgriBuddy/AgriBuddy/src")
from croppulse.config import (
    SILVER_TABLE, GOLD_TABLE,
    PRICE_FALL_THRESHOLD, PRICE_RISE_THRESHOLD
)
from pyspark.sql import functions as F
from pyspark.sql.window import Window

# COMMAND ----------

silver_df = spark.read.table(SILVER_TABLE)
print(f"Input rows: {silver_df.count():,}")

# COMMAND ----------

# MAGIC %md ## Step 1 — Rolling averages using Spark Window functions

# COMMAND ----------

# Window: per crop+mandi, ordered by date, looking back N days
w7  = Window.partitionBy("crop", "mandi").orderBy("date").rowsBetween(-6, 0)
w30 = Window.partitionBy("crop", "mandi").orderBy("date").rowsBetween(-29, 0)

gold_df = (
    silver_df
    .withColumn("avg_7d",  F.round(F.avg("modal_price").over(w7),  2))
    .withColumn("avg_30d", F.round(F.avg("modal_price").over(w30), 2))
    # % change: today vs 7-day average
    .withColumn(
        "pct_change_7d",
        F.round(
            ((F.col("modal_price") - F.col("avg_7d")) / F.col("avg_7d")) * 100,
            2
        )
    )
    # Trend label
    .withColumn(
        "trend",
        F.when(F.col("pct_change_7d") <= PRICE_FALL_THRESHOLD, "FALLING")
         .when(F.col("pct_change_7d") >= PRICE_RISE_THRESHOLD,  "RISING")
         .otherwise("STABLE")
    )
)

print(f"Gold rows computed: {gold_df.count():,}")
display(gold_df.orderBy(F.desc("date")).limit(10))

# COMMAND ----------

# MAGIC %md ## Step 2 — Write Gold Delta table

# COMMAND ----------

(
    gold_df
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .partitionBy("crop", "mandi")
    .saveAsTable(GOLD_TABLE)
)
print(f"Gold table written: {GOLD_TABLE}")

# COMMAND ----------

# MAGIC %md ## Step 3 — Trend distribution check

# COMMAND ----------

display(
    spark.read.table(GOLD_TABLE)
    .groupBy("crop", "mandi", "trend")
    .count()
    .orderBy("crop", "mandi", "trend")
)