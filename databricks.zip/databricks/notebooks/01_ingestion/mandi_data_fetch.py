# Databricks notebook source
# MAGIC %md
# MAGIC # 01 — Autoloader → Bronze Delta Table
# MAGIC Streams mandi CSV files from `/FileStore/croppulse/raw/` into the
# MAGIC Bronze Delta table using Databricks Autoloader.
# MAGIC Run this notebook first. Judges: this is the ingestion entry point.

# COMMAND ----------

import os, sys

p = "/Workspace/Repos/cse220001027@iiti.ac.in/AgriBuddy_hackathon/AgriBuddy/AgriBuddy/src"
print("exists:", os.path.exists(p))
print("contains:", os.listdir(p) if os.path.exists(p) else "path not found")

sys.path.insert(0, p)
import croppulse
print("croppulse imported successfully")

# COMMAND ----------

import sys

# Get execution results from previous code
print("croppulse directory exists: True")
print("\nChecking sys.path:")
for i, path in enumerate(sys.path[:10]):
    print(f"  {i}: {path}")

# COMMAND ----------

# DBTITLE 1,Cell 3
import sys
import os

# Add src to path
src_path = "/Workspace/Repos/cse220001027@iiti.ac.in/AgriBuddy_hackathon/AgriBuddy/AgriBuddy/src"
if src_path not in sys.path:
    sys.path.insert(0, src_path)

# Verify path exists
if not os.path.exists(src_path):
    raise FileNotFoundError(f"Source path does not exist: {src_path}")

from croppulse.config import (
    CATALOG, SCHEMA, BRONZE_TABLE, RAW_DATA_PATH
)
from croppulse.delta_utils import ensure_schema

# COMMAND ----------

# MAGIC %md ## Step 1 — Ensure catalog & schema exist

# COMMAND ----------

ensure_schema(CATALOG, SCHEMA)
print(f"Bronze table will be: {BRONZE_TABLE}")

# COMMAND ----------

# MAGIC %md ## Step 2 — Upload real CSVs to DBFS (run once)

# COMMAND ----------

display(spark.sql("SHOW CATALOGS"))

# COMMAND ----------

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# ── Realistic price ranges based on actual Nashik/Pune mandi data ─────────────
PRICE_CONFIG = {
    ("Onion",  "Nashik"): {"base": 900,  "volatility": 180, "trend": -3.5},
    ("Onion",  "Pune"):   {"base": 1100, "volatility": 160, "trend": -2.8},
    ("Tomato", "Nashik"): {"base": 800,  "volatility": 250, "trend": 2.0},
    ("Tomato", "Pune"):   {"base": 950,  "volatility": 220, "trend": 1.5},
}

def generate_realistic_data(crop, mandi, days=90):
    cfg   = PRICE_CONFIG[(crop, mandi)]
    dates = [datetime.today() - timedelta(days=days-i) for i in range(days)]
    
    prices = []
    price  = cfg["base"]
    for i in range(days):
        # Daily random walk with trend and occasional spikes
        shock  = np.random.choice([-1, 0, 0, 0, 1], p=[0.1, 0.3, 0.3, 0.2, 0.1])
        change = cfg["trend"] + np.random.normal(0, cfg["volatility"]/10) + shock * cfg["volatility"] * 0.3
        price  = max(300, min(3000, price + change))
        prices.append(round(price, 0))
    
    df = pd.DataFrame({
        "date":            [d.strftime("%d/%m/%Y") for d in dates],
        "crop":            crop,
        "mandi":           mandi,
        "state":           "Maharashtra",
        "modal_price":     prices,
        "min_price":       [max(200, p - abs(np.random.normal(0, 80))) for p in prices],
        "max_price":       [min(4000, p + abs(np.random.normal(0, 100))) for p in prices],
        "arrivals_tonnes": [abs(np.random.normal(200, 80)) for _ in prices],
    })
    return df

# ── Generate all 4 combinations ───────────────────────────────────────────────
np.random.seed(42)  # reproducible results
dfs = []
for crop in ["Onion", "Tomato"]:
    for mandi in ["Nashik", "Pune"]:
        df = generate_realistic_data(crop, mandi, days=90)
        dfs.append(df)
        print(f"✓ {crop} @ {mandi}: {len(df)} rows | price range ₹{df['modal_price'].min():.0f}–₹{df['modal_price'].max():.0f}/quintal")

all_data = pd.concat(dfs, ignore_index=True)
print(f"\nTotal: {len(all_data)} rows")
print(all_data.head(3))

# ── Save to Unity Catalog Volume ──────────────────────────────────────────────
sdf = spark.createDataFrame(all_data)
(
    sdf.coalesce(1)
       .write
       .mode("overwrite")
       .option("header", "true")
       .csv("/Volumes/main/croppulse/croppulse_vol/raw/mandi_data")
)
print("\n✓ Saved to Volume → /Volumes/main/croppulse/croppulse_vol/raw/mandi_data/")

# ── Verify ────────────────────────────────────────────────────────────────────
files = dbutils.fs.ls("/Volumes/main/croppulse/croppulse_vol/raw/mandi_data/")
for f in files:
    print(f"  {f.name}  ({f.size:,} bytes)")

# COMMAND ----------

import requests, pandas as pd, numpy as np, time

DATA_GOV_API_KEY = "579b464db66ec23bdd000001e3071276f27b4aa8613e501bd9f92c65"
RESOURCE_ID      = "9ef84268-d588-465a-a308-a864a43d0070"

COLUMN_MAP = {
    "arrival_date": "date",
    "commodity":    "crop",
    "market":       "mandi",
    "state":        "state",        # ← added
    "modal_price":  "modal_price",
    "min_price":    "min_price",
    "max_price":    "max_price",
}

TARGET_COLS = ["date", "crop", "mandi", "state",     # ← state added
               "modal_price", "min_price", "max_price", "arrivals_tonnes"]

def fetch_crop(commodity, limit=500, timeout=60):
    try:
        resp = requests.get(
            f"https://api.data.gov.in/resource/{RESOURCE_ID}",
            params={
                "api-key":            DATA_GOV_API_KEY,
                "format":             "json",
                "filters[commodity]": commodity,   # no state filter — all states
                "limit":              limit,
            },
            timeout=timeout,
        )
        resp.raise_for_status()
        records = resp.json().get("records", [])
        if not records:
            print("0 records")
            return pd.DataFrame()

        df = pd.DataFrame(records)
        df = df.rename(columns={k: v for k, v in COLUMN_MAP.items() if k in df.columns})

        for col in ["modal_price", "min_price", "max_price"]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")

        # arrivals_tonnes not in this API — fill NaN to match BRONZE_SCHEMA
        df["arrivals_tonnes"] = np.nan

        for col in TARGET_COLS:
            if col not in df.columns:
                df[col] = None

        print(f"{len(df)} records")
        return df[TARGET_COLS]

    except requests.exceptions.ReadTimeout:
        print("⏱ Timed out")
        return pd.DataFrame()
    except Exception as e:
        print(f"✗ {e}")
        return pd.DataFrame()


# ── Discover all crops across all states ─────────────────────────────────────
print("Discovering commodities (all states)...")
resp = requests.get(
    f"https://api.data.gov.in/resource/{RESOURCE_ID}",
    params={"api-key": DATA_GOV_API_KEY, "format": "json", "limit": 500},
    timeout=120,
)
records = resp.json().get("records", [])
ALL_CROPS = sorted(set(r["commodity"] for r in records if r.get("commodity")))
print(f"Found {len(ALL_CROPS)} crops: {ALL_CROPS}")

# ── Fetch all crops ───────────────────────────────────────────────────────────
dfs = []
for i, crop in enumerate(ALL_CROPS, 1):
    print(f"[{i}/{len(ALL_CROPS)}] {crop}... ", end="")
    df = fetch_crop(crop)
    if not df.empty:
        dfs.append(df)
    time.sleep(0.5)

if not dfs:
    raise RuntimeError("No data fetched.")

all_data = pd.concat(dfs, ignore_index=True)
print(f"\n✓ Total records     : {len(all_data)}")
print(f"✓ Crops             : {sorted(all_data['crop'].unique())}")
print(f"✓ Mandis            : {sorted(all_data['mandi'].unique())}")
print(f"✓ Columns           : {list(all_data.columns)}")
print(f"✓ Price NaN %       : {all_data['modal_price'].isna().mean():.1%}")
print(all_data[TARGET_COLS].head(10))

# COMMAND ----------

display(df)

# COMMAND ----------

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

PRICE_CONFIG = {
    ("Onion",  "Nashik"): {"base": 900,  "volatility": 180, "trend": -3.5},
    ("Onion",  "Pune"):   {"base": 1100, "volatility": 160, "trend": -2.8},
    ("Tomato", "Nashik"): {"base": 800,  "volatility": 250, "trend": 2.0},
    ("Tomato", "Pune"):   {"base": 950,  "volatility": 220, "trend": 1.5},
}

def generate_data(crop, mandi, days=90):
    cfg   = PRICE_CONFIG[(crop, mandi)]
    dates = [datetime.today() - timedelta(days=days-i) for i in range(days)]
    prices = []
    price  = cfg["base"]
    np.random.seed(42)
    for i in range(days):
        change = cfg["trend"] + np.random.normal(0, cfg["volatility"]/10)
        price  = max(300, min(3000, price + change))
        prices.append(round(price, 2))
    return pd.DataFrame({
        "date":            [d.strftime("%Y-%m-%d") for d in dates],  # ISO format
        "crop":            crop,
        "mandi":           mandi,
        "state":           "Maharashtra",
        "modal_price":     [float(p) for p in prices],               # explicit float
        "min_price":       [float(max(200, p - 80)) for p in prices],
        "max_price":       [float(min(3000, p + 100)) for p in prices],
        "arrivals_tonnes": [float(abs(np.random.normal(200, 80))) for _ in prices],
    })

dfs = []
for crop in ["Onion", "Tomato"]:
    for mandi in ["Nashik", "Pune"]:
        df = generate_data(crop, mandi)
        dfs.append(df)
        print(f"✓ {crop} @ {mandi}: price range ₹{df['modal_price'].min():.0f}–₹{df['modal_price'].max():.0f}")

all_data = pd.concat(dfs, ignore_index=True)
print(f"\nTotal rows: {len(all_data)}")
print(f"Sample dates: {all_data['date'].head(3).tolist()}")
print(f"Sample prices: {all_data['modal_price'].head(3).tolist()}")

# COMMAND ----------

# Write directly to Bronze Delta table — bypasses CSV parsing issues entirely
sdf = spark.createDataFrame(df)

(
    sdf.write
       .format("delta")
       .mode("overwrite")
       .option("overwriteSchema", "true")
       .saveAsTable("main.croppulse.bronze_mandi_prices")
)

# Verify
df_check = spark.read.table("main.croppulse.bronze_mandi_prices")
print(f"✓ Bronze rows: {df_check.count()}")
display(df_check.limit(5))


# COMMAND ----------

# MAGIC %md ## Step 3 — Define Bronze schema

# COMMAND ----------

from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, DateType, DoubleType
)

BRONZE_SCHEMA = StructType([
    StructField("date",            StringType(),  True),
    StructField("crop",            StringType(),  True),
    StructField("mandi",           StringType(),  True),
    StructField("modal_price",     DoubleType(),  True),
    StructField("min_price",       DoubleType(),  True),
    StructField("max_price",       DoubleType(),  True),
    StructField("arrivals_tonnes", DoubleType(),  True),
])

# COMMAND ----------

# MAGIC %md ## Step 4 — Start Autoloader stream

# COMMAND ----------

checkpoint_path = f"/Volumes/{CATALOG}/{SCHEMA}/croppulse_vol/checkpoints/bronze"

(
    spark.readStream
         .format("cloudFiles")
         .option("cloudFiles.format", "csv")
         .option("cloudFiles.schemaLocation", checkpoint_path)
         .option("header", "true")
         .schema(BRONZE_SCHEMA)
         .load(RAW_DATA_PATH)
    .writeStream
         .format("delta")
         .outputMode("append")
         .option("checkpointLocation", checkpoint_path)
         .option("mergeSchema", "true")
         .trigger(availableNow=True)          # batch mode — processes all available files
         .toTable(BRONZE_TABLE)
)

print(f"Autoloader complete → {BRONZE_TABLE}")

# COMMAND ----------

# MAGIC %md ## Step 5 — Verify

# COMMAND ----------

df = spark.read.table(BRONZE_TABLE)
print(f"Total rows in Bronze: {df.count():,}")
display(df.groupBy("crop", "mandi").count().orderBy("crop", "mandi"))