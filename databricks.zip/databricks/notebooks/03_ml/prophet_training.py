# Databricks notebook source
# MAGIC %md
# MAGIC # 04 — Prophet Price Forecasting + MLflow
# MAGIC Trains a Prophet model per crop per mandi on days 1-60.
# MAGIC Logs all runs to MLflow. Open the MLflow UI during the demo.

# COMMAND ----------

# Databricks notebook source
# MAGIC %md
# MAGIC # Croppulse — Train, Backtest, and Register Prophet Model in One Notebook
# MAGIC Fixed version:
# MAGIC 1. uses Databricks REST for experiment creation + run search
# MAGIC 2. uses mlflow.set_tracking_uri("databricks")
# MAGIC 3. uses Unity Catalog model registry with aliases
# MAGIC 4. removes invalid tracking_uri arg from mlflow.start_run()

# COMMAND ----------

# MAGIC %pip install prophet mlflow --quiet
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

import os
import sys
import json
import time
import requests
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import mlflow
import mlflow.prophet

from prophet import Prophet
from pyspark.sql import functions as F
from mlflow.models import infer_signature

# COMMAND ----------

# ====== CONFIG ======
REPO_SRC = "/Workspace/Repos/cse220001027@iiti.ac.in/AgriBuddy_hackathon/AgriBuddy/AgriBuddy/src"

GOLD_TABLE = "main.croppulse.gold_price_features"
MLFLOW_EXPERIMENT_NAME = "/Shared/croppulse_prophet"

# Unity Catalog model name must be catalog.schema.model_name
MODEL_REGISTRY_NAME = "main.croppulse.croppulse_prophet"

CROPS = ["Onion", "Tomato"]
MANDIS = ["Nashik", "Pune"]

FORECAST_PERIODS = 10
TRAIN_DAYS = 60

MODEL_ALIAS = "champion"

# Prophet params
CHANGEPOINT_PRIOR_SCALE = 0.05
SEASONALITY_MODE = "multiplicative"
WEEKLY_SEASONALITY = True
YEARLY_SEASONALITY = False

# COMMAND ----------

if REPO_SRC not in sys.path:
    sys.path.insert(0, REPO_SRC)

# COMMAND ----------

# ====== DATABRICKS AUTH / URI SETUP ======
# Use workspace-backed MLflow tracking plus UC model registry

DATABRICKS_HOST = f"https://{spark.conf.get('spark.databricks.workspaceUrl')}"
DATABRICKS_TOKEN = (
    dbutils.notebook.entry_point.getDbutils()
    .notebook()
    .getContext()
    .apiToken()
    .get()
)

os.environ["DATABRICKS_HOST"] = DATABRICKS_HOST
os.environ["DATABRICKS_TOKEN"] = DATABRICKS_TOKEN

mlflow.set_tracking_uri("databricks")
mlflow.set_registry_uri("databricks-uc")

print("Tracking URI:", mlflow.get_tracking_uri())
print("Registry URI:", mlflow.get_registry_uri())
print("Workspace:", DATABRICKS_HOST)

HEADERS = {
    "Authorization": f"Bearer {DATABRICKS_TOKEN}",
    "Content-Type": "application/json",
}

# COMMAND ----------

# ====== REST HELPERS ======
def api_get(path, params=None):
    r = requests.get(f"{DATABRICKS_HOST}{path}", headers=HEADERS, params=params)
    if not r.ok:
        raise RuntimeError(f"GET {path} failed: {r.status_code} {r.text}")
    return r.json()

def api_post(path, payload=None):
    r = requests.post(f"{DATABRICKS_HOST}{path}", headers=HEADERS, json=payload or {})
    if not r.ok:
        raise RuntimeError(f"POST {path} failed: {r.status_code} {r.text}")
    return r.json()

# COMMAND ----------

# ====== CREATE OR FETCH EXPERIMENT VIA REST ======
def get_or_create_experiment(experiment_name: str) -> str:
    try:
        resp = api_post(
            "/api/2.0/mlflow/experiments/create",
            {"name": experiment_name},
        )
        exp_id = resp["experiment_id"]
        print(f"Created experiment: {experiment_name} -> {exp_id}")
        return exp_id
    except Exception as e:
        msg = str(e)
        if "RESOURCE_ALREADY_EXISTS" not in msg:
            print("Create experiment returned:", msg)

    resp = api_get(
        "/api/2.0/mlflow/experiments/get-by-name",
        {"experiment_name": experiment_name},
    )
    exp_id = resp["experiment"]["experiment_id"]
    print(f"Using existing experiment: {experiment_name} -> {exp_id}")
    return exp_id

EXP_ID = get_or_create_experiment(MLFLOW_EXPERIMENT_NAME)

# Tell MLflow which experiment to log into
mlflow.set_experiment(experiment_id=EXP_ID)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load Gold data

# COMMAND ----------

gold_pdf = (
    spark.read.table(GOLD_TABLE)
    .filter(F.col("crop").isin(CROPS) & F.col("mandi").isin(MANDIS))
    .orderBy("date")
    .toPandas()
)

if gold_pdf.empty:
    raise RuntimeError(f"No rows found in {GOLD_TABLE} for selected crop/mandi filters")

gold_pdf["date"] = pd.to_datetime(gold_pdf["date"])

print(f"Loaded {len(gold_pdf):,} rows")
display(gold_pdf.head(5))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Train one Prophet model per crop-mandi and log to MLflow

# COMMAND ----------

results_summary = []

for crop in CROPS:
    for mandi in MANDIS:
        subset = (
            gold_pdf[(gold_pdf["crop"] == crop) & (gold_pdf["mandi"] == mandi)]
            .rename(columns={"date": "ds", "modal_price": "y"})
            [["ds", "y"]]
            .sort_values("ds")
            .reset_index(drop=True)
        )

        if len(subset) < TRAIN_DAYS + 1:
            print(f"Skipping {crop}-{mandi}: only {len(subset)} rows")
            continue

        train_df = subset.iloc[:TRAIN_DAYS].copy()
        test_df = subset.iloc[TRAIN_DAYS:].copy()

        print(f"\nTraining {crop} @ {mandi} ...")

        with mlflow.start_run(
            run_name=f"{crop}_{mandi}",
            experiment_id=EXP_ID,
        ) as run:
            run_id = run.info.run_id

            mlflow.log_params({
                "crop": crop,
                "mandi": mandi,
                "train_days": TRAIN_DAYS,
                "forecast_periods": FORECAST_PERIODS,
                "changepoint_prior_scale": CHANGEPOINT_PRIOR_SCALE,
                "seasonality_mode": SEASONALITY_MODE,
                "weekly_seasonality": WEEKLY_SEASONALITY,
                "yearly_seasonality": YEARLY_SEASONALITY,
            })

            model = Prophet(
                changepoint_prior_scale=CHANGEPOINT_PRIOR_SCALE,
                seasonality_mode=SEASONALITY_MODE,
                weekly_seasonality=WEEKLY_SEASONALITY,
                yearly_seasonality=YEARLY_SEASONALITY,
            )
            model.fit(train_df)

            future = model.make_future_dataframe(periods=len(test_df), freq="D")
            forecast = model.predict(future)

            pred = forecast.iloc[TRAIN_DAYS:][["ds", "yhat"]].reset_index(drop=True)

            if len(test_df) > 0 and len(pred) > 0:
                n = min(len(test_df), len(pred))
                actual = test_df["y"].values[:n]
                preds = pred["yhat"].values[:n]

                # safer MAPE if any actual value is zero
                nonzero_mask = actual != 0
                if np.any(nonzero_mask):
                    mape = float(np.mean(np.abs((actual[nonzero_mask] - preds[nonzero_mask]) / actual[nonzero_mask])) * 100)
                else:
                    mape = 999.0

                mae = float(np.mean(np.abs(actual - preds)))
                rmse = float(np.sqrt(np.mean((actual - preds) ** 2)))
            else:
                mape, mae, rmse = 999.0, 999.0, 999.0

            mlflow.log_metrics({
                "MAPE": round(mape, 2),
                "MAE": round(mae, 2),
                "RMSE": round(rmse, 2),
            })

            sample_input = future.head(5)
            sample_output = forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].head(5)
            signature = infer_signature(sample_input, sample_output)

            # log model artifact inside run
            mlflow.prophet.log_model(
                pr_model=model,
                artifact_path="prophet_model",
                signature=signature,
            )

            results_summary.append({
                "crop": crop,
                "mandi": mandi,
                "MAPE": round(mape, 2),
                "MAE": round(mae, 2),
                "RMSE": round(rmse, 2),
                "run_id": run_id,
            })

            print(f"  run_id={run_id}")
            print(f"  MAPE={mape:.2f}% | MAE=₹{mae:.2f} | RMSE={rmse:.2f}")

# COMMAND ----------

if not results_summary:
    raise RuntimeError("No MLflow runs were logged. Check data availability and TRAIN_DAYS setting.")

results_df = pd.DataFrame(results_summary).sort_values("MAPE").reset_index(drop=True)
display(results_df)

print("\n=== Training Summary ===")
for _, r in results_df.iterrows():
    flag = "GOOD" if r["MAPE"] < 20 else "CHECK"
    print(
        f"{r['crop']:8} {r['mandi']:8}  "
        f"MAPE={r['MAPE']:6.2f}%  "
        f"MAE=₹{r['MAE']:8.2f}  "
        f"RMSE={r['RMSE']:8.2f}  "
        f"{flag}"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Back-test: load best run per crop-mandi and compare actual vs predicted

# COMMAND ----------

def search_runs_rest(experiment_id: str, max_results: int = 500):
    payload = {
        "experiment_ids": [experiment_id],
        "max_results": max_results,
        "order_by": ["metrics.MAPE ASC"],
    }
    resp = api_post("/api/2.0/mlflow/runs/search", payload)
    return resp.get("runs", [])

runs = search_runs_rest(EXP_ID)
print(f"Found {len(runs)} runs")

# COMMAND ----------

summary_rows = []

for crop in CROPS:
    for mandi in MANDIS:
        best_run = None

        for r in runs:
            params = {p["key"]: p["value"] for p in r.get("data", {}).get("params", [])}
            if params.get("crop") == crop and params.get("mandi") == mandi:
                best_run = r
                break

        if best_run is None:
            print(f"No run found for {crop}-{mandi}")
            continue

        run_id = best_run["info"]["run_id"]
        model_uri = f"runs:/{run_id}/prophet_model"
        model = mlflow.prophet.load_model(model_uri)

        subset = (
            gold_pdf[(gold_pdf["crop"] == crop) & (gold_pdf["mandi"] == mandi)]
            .rename(columns={"date": "ds", "modal_price": "y"})
            [["ds", "y"]]
            .sort_values("ds")
            .reset_index(drop=True)
        )

        # future = model.make_future_dataframe(periods=0)
        # forecast = model.predict(future)
        # preds = forecast[["ds", "yhat"]].set_index("ds")
        test_slice = subset.iloc[TRAIN_DAYS:].copy()

        future = model.make_future_dataframe(periods=len(test_slice), freq="D")
        forecast = model.predict(future)

        preds = (
            forecast[["ds", "yhat"]]
            .merge(test_slice[["ds"]], on="ds", how="inner")
            .set_index("ds")
        )

        test_slice = subset.iloc[TRAIN_DAYS:]
        for _, row in test_slice.iterrows():
            if row["ds"] in preds.index:
                pred_price = float(preds.loc[row["ds"], "yhat"])
                actual_price = float(row["y"])
                err_pct = ((actual_price - pred_price) / actual_price) * 100 if actual_price != 0 else 0.0

                summary_rows.append({
                    "Crop": crop,
                    "Mandi": mandi,
                    "Date": str(row["ds"].date()),
                    "Actual (₹)": round(actual_price, 2),
                    "Predicted (₹)": round(pred_price, 2),
                    "Error %": round(err_pct, 2),
                    "run_id": run_id,
                })

summary_df = pd.DataFrame(summary_rows)

if summary_df.empty:
    raise RuntimeError("Back-test summary is empty")

display(summary_df.head(20))

mape_by_crop = (
    summary_df.groupby(["Crop", "Mandi"])
    .apply(lambda g: round(g["Error %"].abs().mean(), 2))
    .reset_index(name="MAPE (%)")
)
print("\n=== Back-test MAPE Summary ===")
display(mape_by_crop)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Visualisation

# COMMAND ----------

fig, axes = plt.subplots(
    len(CROPS),
    len(MANDIS),
    figsize=(12, 5 * len(CROPS)),
    facecolor="white"
)

if len(CROPS) == 1 and len(MANDIS) == 1:
    axes = np.array([[axes]])
elif len(CROPS) == 1:
    axes = np.array([axes])
elif len(MANDIS) == 1:
    axes = np.array([[ax] for ax in axes])

for i, crop in enumerate(CROPS):
    for j, mandi in enumerate(MANDIS):
        ax = axes[i][j]
        data = summary_df[(summary_df["Crop"] == crop) & (summary_df["Mandi"] == mandi)]

        if data.empty:
            ax.set_title(f"{crop} — {mandi} (no data)")
            ax.axis("off")
            continue

        ax.plot(data["Date"], data["Actual (₹)"], "o-", label="Actual", markersize=4)
        ax.plot(data["Date"], data["Predicted (₹)"], "s--", label="Predicted", markersize=4)
        ax.set_title(f"{crop} — {mandi}", fontsize=11)
        ax.set_xlabel("Date")
        ax.set_ylabel("₹/quintal")
        ax.legend(fontsize=8)
        ax.tick_params(axis="x", rotation=45, labelsize=7)
        ax.grid(axis="y", alpha=0.3)

fig.suptitle("Back-test: Days after training window — Predicted vs Actual", fontsize=13, y=1.02)
plt.tight_layout()
display(fig)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Register the best overall run in Unity Catalog

# COMMAND ----------

if results_df.empty:
    raise RuntimeError("No MLflow runs were logged")

best_run_id = results_df.iloc[0]["run_id"]
best_crop = results_df.iloc[0]["crop"]
best_mandi = results_df.iloc[0]["mandi"]
best_mape = results_df.iloc[0]["MAPE"]

print("Best overall run")
print("run_id:", best_run_id)
print("crop:", best_crop)
print("mandi:", best_mandi)
print("MAPE:", best_mape)

model_uri = f"runs:/{best_run_id}/prophet_model"

registered = mlflow.register_model(
    model_uri=model_uri,
    name=MODEL_REGISTRY_NAME,
)

print(f"Registered model: {MODEL_REGISTRY_NAME}")
print(f"Version: {registered.version}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Assign alias
# MAGIC Unity Catalog uses aliases, not stages.

# COMMAND ----------

client = mlflow.tracking.MlflowClient(
    tracking_uri="databricks",
    registry_uri="databricks-uc",
)

client.set_registered_model_alias(
    name=MODEL_REGISTRY_NAME,
    alias=MODEL_ALIAS,
    version=registered.version,
)

print(f"Alias '{MODEL_ALIAS}' now points to version {registered.version}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Verify: load by alias and predict

# COMMAND ----------

registered_model = mlflow.pyfunc.load_model(
    model_uri=f"models:/{MODEL_REGISTRY_NAME}@{MODEL_ALIAS}"
)

prophet_model = mlflow.prophet.load_model(
    model_uri=f"models:/{MODEL_REGISTRY_NAME}@{MODEL_ALIAS}"
)

future = prophet_model.make_future_dataframe(periods=FORECAST_PERIODS, freq="D")
forecast = prophet_model.predict(future)

print(f"\n{FORECAST_PERIODS}-day forecast:")
display(forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].tail(FORECAST_PERIODS))

# COMMAND ----------

print("\nDone.")
print("Experiment:", MLFLOW_EXPERIMENT_NAME)
print("Registered UC model:", MODEL_REGISTRY_NAME)
print("Alias:", MODEL_ALIAS)

# COMMAND ----------

# Databricks notebook source
# MAGIC %md
# MAGIC # Croppulse — Train, Backtest, Track in MLflow, and Save Best Prophet Model to Volume
# MAGIC
# MAGIC This version:
# MAGIC 1. uses Databricks MLflow tracking
# MAGIC 2. fixes the back-test logic
# MAGIC 3. does NOT use Unity Catalog model registry (avoids S3 AccessDenied)
# MAGIC 4. saves the best model to a Volume for reuse later

# COMMAND ----------

# MAGIC %pip install prophet mlflow --quiet
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

import os
import sys
import json
import time
import pickle
import requests
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import mlflow
import mlflow.prophet

from prophet import Prophet
from pyspark.sql import functions as F
from mlflow.models import infer_signature

# COMMAND ----------

# ====== CONFIG ======
REPO_SRC = "/Workspace/Repos/cse220001027@iiti.ac.in/AgriBuddy_hackathon/AgriBuddy/AgriBuddy/src"

GOLD_TABLE = "main.croppulse.gold_price_features"
MLFLOW_EXPERIMENT_NAME = "/Shared/croppulse_prophet"

CROPS = ["Onion", "Tomato"]
MANDIS = ["Nashik", "Pune"]

FORECAST_PERIODS = 10
TRAIN_DAYS = 60

# Save best model here instead of UC registry
MODEL_VOLUME_DIR = "/Volumes/main/croppulse/croppulse_vol/models/prophet_best"

# Prophet params
CHANGEPOINT_PRIOR_SCALE = 0.05
SEASONALITY_MODE = "multiplicative"
WEEKLY_SEASONALITY = True
YEARLY_SEASONALITY = False

# COMMAND ----------

if REPO_SRC not in sys.path:
    sys.path.insert(0, REPO_SRC)

# COMMAND ----------

# ====== DATABRICKS AUTH / URI SETUP ======
DATABRICKS_HOST = f"https://{spark.conf.get('spark.databricks.workspaceUrl')}"
DATABRICKS_TOKEN = (
    dbutils.notebook.entry_point.getDbutils()
    .notebook()
    .getContext()
    .apiToken()
    .get()
)

os.environ["DATABRICKS_HOST"] = DATABRICKS_HOST
os.environ["DATABRICKS_TOKEN"] = DATABRICKS_TOKEN

mlflow.set_tracking_uri("databricks")

print("Tracking URI:", mlflow.get_tracking_uri())
print("Workspace:", DATABRICKS_HOST)

HEADERS = {
    "Authorization": f"Bearer {DATABRICKS_TOKEN}",
    "Content-Type": "application/json",
}

# COMMAND ----------

# ====== REST HELPERS ======
def api_get(path, params=None):
    r = requests.get(f"{DATABRICKS_HOST}{path}", headers=HEADERS, params=params)
    if not r.ok:
        raise RuntimeError(f"GET {path} failed: {r.status_code} {r.text}")
    return r.json()

def api_post(path, payload=None):
    r = requests.post(f"{DATABRICKS_HOST}{path}", headers=HEADERS, json=payload or {})
    if not r.ok:
        raise RuntimeError(f"POST {path} failed: {r.status_code} {r.text}")
    return r.json()

# COMMAND ----------

# ====== CREATE OR FETCH EXPERIMENT VIA REST ======
def get_or_create_experiment(experiment_name: str) -> str:
    try:
        resp = api_post(
            "/api/2.0/mlflow/experiments/create",
            {"name": experiment_name},
        )
        exp_id = resp["experiment_id"]
        print(f"Created experiment: {experiment_name} -> {exp_id}")
        return exp_id
    except Exception as e:
        msg = str(e)
        if "RESOURCE_ALREADY_EXISTS" not in msg:
            print("Create experiment returned:", msg)

    resp = api_get(
        "/api/2.0/mlflow/experiments/get-by-name",
        {"experiment_name": experiment_name},
    )
    exp_id = resp["experiment"]["experiment_id"]
    print(f"Using existing experiment: {experiment_name} -> {exp_id}")
    return exp_id

EXP_ID = get_or_create_experiment(MLFLOW_EXPERIMENT_NAME)
mlflow.set_experiment(experiment_id=EXP_ID)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load Gold data

# COMMAND ----------

gold_pdf = (
    spark.read.table(GOLD_TABLE)
    .filter(F.col("crop").isin(CROPS) & F.col("mandi").isin(MANDIS))
    .orderBy("date")
    .toPandas()
)

if gold_pdf.empty:
    raise RuntimeError(f"No rows found in {GOLD_TABLE} for selected crop/mandi filters")

gold_pdf["date"] = pd.to_datetime(gold_pdf["date"])

print(f"Loaded {len(gold_pdf):,} rows")
display(gold_pdf.head(5))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Train one Prophet model per crop-mandi and log to MLflow

# COMMAND ----------

results_summary = []

for crop in CROPS:
    for mandi in MANDIS:
        subset = (
            gold_pdf[(gold_pdf["crop"] == crop) & (gold_pdf["mandi"] == mandi)]
            .rename(columns={"date": "ds", "modal_price": "y"})
            [["ds", "y"]]
            .sort_values("ds")
            .reset_index(drop=True)
        )

        if len(subset) < TRAIN_DAYS + 1:
            print(f"Skipping {crop}-{mandi}: only {len(subset)} rows")
            continue

        train_df = subset.iloc[:TRAIN_DAYS].copy()
        test_df = subset.iloc[TRAIN_DAYS:].copy()

        print(f"\nTraining {crop} @ {mandi} ...")

        with mlflow.start_run(
            run_name=f"{crop}_{mandi}",
            experiment_id=EXP_ID,
        ) as run:
            run_id = run.info.run_id

            mlflow.log_params({
                "crop": crop,
                "mandi": mandi,
                "train_days": TRAIN_DAYS,
                "forecast_periods": FORECAST_PERIODS,
                "changepoint_prior_scale": CHANGEPOINT_PRIOR_SCALE,
                "seasonality_mode": SEASONALITY_MODE,
                "weekly_seasonality": WEEKLY_SEASONALITY,
                "yearly_seasonality": YEARLY_SEASONALITY,
            })

            model = Prophet(
                changepoint_prior_scale=CHANGEPOINT_PRIOR_SCALE,
                seasonality_mode=SEASONALITY_MODE,
                weekly_seasonality=WEEKLY_SEASONALITY,
                yearly_seasonality=YEARLY_SEASONALITY,
            )
            model.fit(train_df)

            future = model.make_future_dataframe(periods=len(test_df), freq="D")
            forecast = model.predict(future)

            pred = (
                forecast[["ds", "yhat"]]
                .merge(test_df[["ds"]], on="ds", how="inner")
                .reset_index(drop=True)
            )

            if len(test_df) > 0 and len(pred) > 0:
                merged_eval = test_df.merge(pred, on="ds", how="inner")
                actual = merged_eval["y"].values
                preds = merged_eval["yhat"].values

                nonzero_mask = actual != 0
                if np.any(nonzero_mask):
                    mape = float(
                        np.mean(
                            np.abs((actual[nonzero_mask] - preds[nonzero_mask]) / actual[nonzero_mask])
                        ) * 100
                    )
                else:
                    mape = 999.0

                mae = float(np.mean(np.abs(actual - preds)))
                rmse = float(np.sqrt(np.mean((actual - preds) ** 2)))
            else:
                mape, mae, rmse = 999.0, 999.0, 999.0

            mlflow.log_metrics({
                "MAPE": round(mape, 2),
                "MAE": round(mae, 2),
                "RMSE": round(rmse, 2),
            })

            sample_input = future.head(5)
            sample_output = forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].head(5)
            signature = infer_signature(sample_input, sample_output)

            mlflow.prophet.log_model(
                pr_model=model,
                artifact_path="prophet_model",
                signature=signature,
            )

            results_summary.append({
                "crop": crop,
                "mandi": mandi,
                "MAPE": round(mape, 2),
                "MAE": round(mae, 2),
                "RMSE": round(rmse, 2),
                "run_id": run_id,
            })

            print(f"  run_id={run_id}")
            print(f"  test_rows={len(test_df)} | matched_preds={len(pred)}")
            print(f"  MAPE={mape:.2f}% | MAE=₹{mae:.2f} | RMSE={rmse:.2f}")

# COMMAND ----------

if not results_summary:
    raise RuntimeError("No MLflow runs were logged. Check data availability and TRAIN_DAYS setting.")

results_df = pd.DataFrame(results_summary).sort_values("MAPE").reset_index(drop=True)
display(results_df)

print("\n=== Training Summary ===")
for _, r in results_df.iterrows():
    flag = "GOOD" if r["MAPE"] < 20 else "CHECK"
    print(
        f"{r['crop']:8} {r['mandi']:8}  "
        f"MAPE={r['MAPE']:6.2f}%  "
        f"MAE=₹{r['MAE']:8.2f}  "
        f"RMSE={r['RMSE']:8.2f}  "
        f"{flag}"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Back-test: load best run per crop-mandi and compare actual vs predicted

# COMMAND ----------

def search_runs_rest(experiment_id: str, max_results: int = 500):
    payload = {
        "experiment_ids": [experiment_id],
        "max_results": max_results,
        "order_by": ["metrics.MAPE ASC"],
    }
    resp = api_post("/api/2.0/mlflow/runs/search", payload)
    return resp.get("runs", [])

runs = search_runs_rest(EXP_ID)
print(f"Found {len(runs)} runs")

# COMMAND ----------

summary_rows = []

for crop in CROPS:
    for mandi in MANDIS:
        best_run = None

        for r in runs:
            params = {p["key"]: p["value"] for p in r.get("data", {}).get("params", [])}
            if params.get("crop") == crop and params.get("mandi") == mandi:
                best_run = r
                break

        if best_run is None:
            print(f"No run found for {crop}-{mandi}")
            continue

        run_id = best_run["info"]["run_id"]
        model_uri = f"runs:/{run_id}/prophet_model"
        model = mlflow.prophet.load_model(model_uri)

        subset = (
            gold_pdf[(gold_pdf["crop"] == crop) & (gold_pdf["mandi"] == mandi)]
            .rename(columns={"date": "ds", "modal_price": "y"})
            [["ds", "y"]]
            .sort_values("ds")
            .reset_index(drop=True)
        )

        if len(subset) <= TRAIN_DAYS:
            print(f"Skipping back-test for {crop}-{mandi}: not enough rows")
            continue

        test_slice = subset.iloc[TRAIN_DAYS:].copy()

        future = model.make_future_dataframe(periods=len(test_slice), freq="D")
        forecast = model.predict(future)

        preds = (
            forecast[["ds", "yhat"]]
            .merge(test_slice[["ds"]], on="ds", how="inner")
            .set_index("ds")
        )

        matched = 0
        for _, row in test_slice.iterrows():
            if row["ds"] in preds.index:
                pred_price = float(preds.loc[row["ds"], "yhat"])
                actual_price = float(row["y"])
                err_pct = ((actual_price - pred_price) / actual_price) * 100 if actual_price != 0 else 0.0

                summary_rows.append({
                    "Crop": crop,
                    "Mandi": mandi,
                    "Date": row["ds"],
                    "Actual (₹)": round(actual_price, 2),
                    "Predicted (₹)": round(pred_price, 2),
                    "Error %": round(err_pct, 2),
                    "run_id": run_id,
                })
                matched += 1

        print(f"{crop}-{mandi}: matched {matched}/{len(test_slice)} back-test rows")

summary_df = pd.DataFrame(summary_rows)

if summary_df.empty:
    raise RuntimeError("Back-test summary is empty")

summary_df["Date"] = pd.to_datetime(summary_df["Date"])
display(summary_df.head(20))

mape_by_crop = (
    summary_df.groupby(["Crop", "Mandi"])
    .apply(lambda g: round(g["Error %"].abs().mean(), 2))
    .reset_index(name="MAPE (%)")
)

print("\n=== Back-test MAPE Summary ===")
display(mape_by_crop)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Visualisation

# COMMAND ----------

fig, axes = plt.subplots(
    len(CROPS),
    len(MANDIS),
    figsize=(12, 5 * len(CROPS)),
    facecolor="white"
)

if len(CROPS) == 1 and len(MANDIS) == 1:
    axes = np.array([[axes]])
elif len(CROPS) == 1:
    axes = np.array([axes])
elif len(MANDIS) == 1:
    axes = np.array([[ax] for ax in axes])

for i, crop in enumerate(CROPS):
    for j, mandi in enumerate(MANDIS):
        ax = axes[i][j]
        data = (
            summary_df[(summary_df["Crop"] == crop) & (summary_df["Mandi"] == mandi)]
            .sort_values("Date")
        )

        if data.empty:
            ax.set_title(f"{crop} — {mandi} (no data)")
            ax.axis("off")
            continue

        ax.plot(data["Date"], data["Actual (₹)"], "o-", label="Actual", markersize=4)
        ax.plot(data["Date"], data["Predicted (₹)"], "s--", label="Predicted", markersize=4)
        ax.set_title(f"{crop} — {mandi}", fontsize=11)
        ax.set_xlabel("Date")
        ax.set_ylabel("₹/quintal")
        ax.legend(fontsize=8)
        ax.tick_params(axis="x", rotation=45, labelsize=7)
        ax.grid(axis="y", alpha=0.3)

fig.suptitle("Back-test: Days after training window — Predicted vs Actual", fontsize=13, y=1.02)
plt.tight_layout()
display(fig)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Save best model to Volume (direct Python write)

# COMMAND ----------

import os
import json
import pickle

if results_df.empty:
    raise RuntimeError("No MLflow runs were logged")

best_run_id = results_df.iloc[0]["run_id"]
best_crop = results_df.iloc[0]["crop"]
best_mandi = results_df.iloc[0]["mandi"]
best_mape = results_df.iloc[0]["MAPE"]

print("Best overall run")
print("run_id:", best_run_id)
print("crop:", best_crop)
print("mandi:", best_mandi)
print("MAPE:", best_mape)

model_uri = f"runs:/{best_run_id}/prophet_model"
best_model = mlflow.prophet.load_model(model_uri)

# POSIX path for Unity Catalog volume
MODEL_VOLUME_DIR = "/Volumes/main/croppulse/croppulse_vol/models/prophet_best"
os.makedirs(MODEL_VOLUME_DIR, exist_ok=True)

model_save_path = os.path.join(MODEL_VOLUME_DIR, "model.pkl")
metadata_save_path = os.path.join(MODEL_VOLUME_DIR, "metadata.json")

with open(model_save_path, "wb") as f:
    pickle.dump(best_model, f)

metadata = {
    "best_run_id": best_run_id,
    "crop": best_crop,
    "mandi": best_mandi,
    "mape": float(best_mape),
    "forecast_periods": FORECAST_PERIODS,
    "train_days": TRAIN_DAYS,
    "saved_at": pd.Timestamp.now().isoformat(),
    "source_model_uri": model_uri,
}

with open(metadata_save_path, "w") as f:
    json.dump(metadata, f, indent=2)

print(f"Saved model to: {model_save_path}")
print(f"Saved metadata to: {metadata_save_path}")

# COMMAND ----------

import pickle
import json

MODEL_VOLUME_DIR = "/Volumes/main/croppulse/croppulse_vol/models/prophet_best"

model_load_path = f"{MODEL_VOLUME_DIR}/model.pkl"
metadata_load_path = f"{MODEL_VOLUME_DIR}/metadata.json"

# Load model
with open(model_load_path, "rb") as f:
    loaded_model = pickle.load(f)

# Load metadata (optional but useful)
with open(metadata_load_path, "r") as f:
    metadata = json.load(f)

print("Loaded model from:", model_load_path)
print("Metadata:", metadata)

# COMMAND ----------

# Create future dataframe
future = loaded_model.make_future_dataframe(periods=metadata["forecast_periods"])

# Predict
forecast = loaded_model.predict(future)

display(forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].tail())